# PlanBraid Hostinger upgrade v2.2.0

This package updates an existing PlanBraid Hostinger installation from v2.1.4.
It is not a fresh installer or a replacement for the separate home-server
release. It includes the compact PM dashboard and the Supply Manager role.

The package contains application source only. It does not contain account data,
credentials, backups, or the live Supply database. No database migration is
required for v2.2.0.

## Before installing

1. Schedule downtime. Ask users to save unsynced work and sign out.
2. Back up the current application files, including `.htaccess`, and the
   private `planbraid-private` directory. Back up the MySQL database and the
   existing `planbraid-private/supply.sqlite` file as well.
3. Keep backups outside every web root and verify they are complete and
   restorable before replacing files.
4. Confirm the target is the existing PlanBraid `public_html`, not another
   domain or the separate legacy Supply application.

Do not install until both application and database backups have been verified.

## Install

1. Extract this archive outside the web root.
2. Upload the **contents** of `public_html/` to the existing PlanBraid
   `public_html/`, merging directories and replacing matching application
   files. Preserve the existing `.htaccess` and unrelated files.
3. Do not upload the archive itself as a web-root file. Do not replace or
   move `planbraid-private/database.php` or `planbraid-private/supply.sqlite`.
   Do not run a SQL migration for this release.
4. Keep the verified backups until the update has been tested and accepted.

The application continues to use the existing private MySQL configuration and
Supply database beside `public_html`; neither is included in this package.

## Verify

- Confirm the landing page and app open over HTTPS, then sign in and save a
  disposable note.
- Confirm the PM view loads the existing shared tracker and displays the
  compact dashboard.
- Enable Supply for a test account and assign the Manager role. Verify the
  manager can edit catalog items and categories, manage orders and settings,
  but cannot administer PlanBraid accounts.
- Verify a Technician still cannot edit the catalog, settings, or other users'
  orders.
- Open the License dialog and confirm its source-code link downloads
  `planbraid-source.zip`.
- Check the PHP error log and verify that the private configuration and
  database files are not web-accessible.

## Rollback

Stop user access, preserve a backup of the current state, then restore the
application files and databases together from the verified pre-upgrade backup.
Restoring the MySQL or Supply database also discards changes made since that
backup.

## Contents

- `public_html/` — deployable application files; `.htaccess` is intentionally
  excluded so the existing host rules are preserved.
- `public_html/planbraid-source.zip` — source archive linked from the License
  dialog.
