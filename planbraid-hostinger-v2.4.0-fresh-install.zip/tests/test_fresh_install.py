# PlanBraid - outlining, project tracking, and material orders.
# Copyright (C) 2026 Robert Wasniowski
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Exercise the fresh installer with isolated databases and synthetic accounts."""
import http.client
import json
import os
from pathlib import Path
import pty
import secrets
import select
import shutil
import socket
import sqlite3
import subprocess
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
ADMIN = "fresh_admin"
PASSWORD = "synthetic-password-123"
DB_PASSWORD = "synthetic-database-password"


class FreshInstallTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="planbraid-fresh-test-")
        cls.path = Path(cls.temp.name)
        cls.socket = cls.path / "mysql.sock"
        subprocess.run(
            ["mariadb-install-db", "--no-defaults", "--datadir=" + str(cls.path / "db"),
             "--auth-root-authentication-method=normal", "--skip-test-db"],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        )
        cls.db = subprocess.Popen(
            ["mariadbd", "--no-defaults", "--datadir=" + str(cls.path / "db"),
             "--socket=" + str(cls.socket), "--pid-file=" + str(cls.path / "mysql.pid"),
             "--skip-networking", "--log-error=" + str(cls.path / "mysql.log")],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        try:
            for _ in range(100):
                if cls.db.poll() is not None:
                    raise RuntimeError("MariaDB failed to start: " + (cls.path / "mysql.log").read_text())
                if cls.socket.exists():
                    ping = subprocess.run(
                        ["mariadb-admin", "--no-defaults", "--socket=" + str(cls.socket),
                         "-u", "root", "ping"], capture_output=True,
                    )
                    if ping.returncode == 0:
                        break
                time.sleep(0.1)
            else:
                raise RuntimeError("MariaDB did not start")
            cls.sql("CREATE USER 'pb_test'@'localhost' IDENTIFIED BY '" + DB_PASSWORD + "'")
            ini_dir = cls.path / "php-ini"
            ini_dir.mkdir()
            sessions = cls.path / "sessions"
            sessions.mkdir()
            (ini_dir / "test.ini").write_text(
                "disable_functions=shell_exec,exec,system,proc_open,popen\n"
                'session.save_path="' + str(sessions) + '"\n'
            )
            cls.env = {**os.environ, "PHP_INI_SCAN_DIR": ":" + str(ini_dir)}
        except Exception:
            cls.cleanup()
            raise

    @classmethod
    def sql(cls, text):
        result = subprocess.run(
            ["mariadb", "--no-defaults", "--socket=" + str(cls.socket),
             "-u", "root", "--batch", "--skip-column-names"],
            input=text, text=True, check=True, capture_output=True,
        )
        return result.stdout.strip()

    @classmethod
    def cleanup(cls):
        if cls.db.poll() is None:
            cls.db.terminate()
            cls.db.wait(timeout=15)
        cls.temp.cleanup()

    @classmethod
    def tearDownClass(cls):
        cls.cleanup()

    def site(self, name, full_app=False, parent=None):
        database = "fresh_" + name
        self.sql("CREATE DATABASE `" + database + "`; GRANT ALL PRIVILEGES ON `" +
                 database + "`.* TO 'pb_test'@'localhost'")
        site = (parent or self.path) / name
        site.mkdir()
        if full_app:
            shutil.copytree(ROOT / "public_html", site / "public_html")
        else:
            (site / "public_html").mkdir()
        shutil.copytree(ROOT / "tools", site / "tools")
        private = site / "planbraid-private"
        private.mkdir()
        (private / "database.php").write_text(
            "<?php return ["
            "'host' => 'localhost;unix_socket=" + str(self.socket) + "',"
            "'database' => '" + database + "',"
            "'username' => 'pb_test',"
            "'password' => '" + DB_PASSWORD + "'];"
        )
        return site, database

    def setup(self, site, password=PASSWORD, confirmation=PASSWORD):
        return subprocess.run(
            ["php", str(site / "tools/setup.php"), "--stdin"],
            input=ADMIN + "\n" + password + "\n" + confirmation + "\n",
            text=True, capture_output=True, env=self.env, timeout=30,
        )

    def test_existing_mysql_database_is_untouched(self):
        site, database = self.site("existing_mysql")
        self.sql("USE `" + database + "`; CREATE TABLE keep_me (value INT); INSERT INTO keep_me VALUES (42)")
        result = self.setup(site)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("database is not empty", result.stderr)
        self.assertEqual(self.sql("SHOW TABLES FROM `" + database + "`"), "keep_me")
        self.assertEqual(self.sql("SELECT value FROM `" + database + "`.keep_me"), "42")
        self.assertFalse((site / "planbraid-private/supply.sqlite").exists())

    def test_existing_supply_database_is_untouched(self):
        site, database = self.site("existing_supply")
        supply = site / "planbraid-private/supply.sqlite"
        supply.write_bytes(b"existing synthetic data")
        result = self.setup(site)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Supply database already exists", result.stderr)
        self.assertEqual(supply.read_bytes(), b"existing synthetic data")
        self.assertEqual(self.sql("SHOW TABLES FROM `" + database + "`"), "")

    def test_invalid_inputs_do_not_initialize_any_database(self):
        site, database = self.site("invalid")
        no_terminal = subprocess.run(
            ["sh", str(site / "tools/install.sh")], input="", text=True,
            capture_output=True, env=self.env, timeout=30,
        )
        self.assertNotEqual(no_terminal.returncode, 0)
        self.assertIn("interactive SSH terminal", no_terminal.stderr)
        bad_password = self.setup(site, password="short", confirmation="short")
        self.assertNotEqual(bad_password.returncode, 0)
        self.assertIn("12-72 bytes", bad_password.stderr)
        mismatch = self.setup(site, confirmation="different-password")
        self.assertNotEqual(mismatch.returncode, 0)
        self.assertEqual(self.sql("SHOW TABLES FROM `" + database + "`"), "")
        self.assertFalse((site / "planbraid-private/supply.sqlite").exists())

    def test_installation_inside_an_existing_web_root_is_refused(self):
        parent = self.path / "public_html"
        parent.mkdir()
        site, database = self.site("nested", parent=parent)
        result = self.setup(site)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("outside the web root", result.stderr)
        supply = subprocess.run(
            ["php", str(site / "tools/setup-supply.php")],
            capture_output=True, text=True, env=self.env, timeout=30,
        )
        self.assertNotEqual(supply.returncode, 0)
        self.assertIn("outside the web root", supply.stderr)
        self.assertEqual(self.sql("SHOW TABLES FROM `" + database + "`"), "")
        self.assertFalse((site / "planbraid-private/supply.sqlite").exists())

    def install_interactively(self, site):
        master, slave = pty.openpty()
        process = subprocess.Popen(
            ["sh", str(site / "tools/install.sh")], stdin=slave, stdout=slave,
            stderr=slave, env=self.env, close_fds=True,
        )
        os.close(slave)
        output = bytearray()
        prompts = [
            (b"Administrator username", ADMIN),
            (b"Administrator password", PASSWORD),
            (b"Repeat password", PASSWORD),
        ]
        sent = 0
        deadline = time.monotonic() + 300
        try:
            while time.monotonic() < deadline:
                readable, _, _ = select.select([master], [], [], 0.1)
                if readable:
                    try:
                        chunk = os.read(master, 8192)
                    except OSError:
                        break
                    if not chunk:
                        break
                    output.extend(chunk)
                if sent < len(prompts) and prompts[sent][0] in output:
                    os.write(master, (prompts[sent][1] + "\n").encode())
                    sent += 1
                if process.poll() is not None and not readable:
                    break
            else:
                self.fail("Installer timed out: " + output.decode(errors="replace"))
            status = process.wait(timeout=10)
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=10)
            os.close(master)
        text = output.decode(errors="replace")
        self.assertEqual(sent, 3, text)
        self.assertEqual(status, 0, text)
        self.assertNotIn(PASSWORD, text)
        self.assertIn("Fresh installation complete", text)

    def test_fresh_installation_and_application(self):
        site, database = self.site("complete", full_app=True)
        self.install_interactively(site)
        self.assertEqual(self.sql("SELECT COUNT(*) FROM `" + database + "`.sl_country_ranges"), "732796")
        self.assertEqual(
            self.sql("SELECT is_admin, enabled, pm_enabled, supply_enabled FROM `" +
                     database + "`.sl_account_access"), "1\t1\t0\t0",
        )
        supply = site / "planbraid-private/supply.sqlite"
        self.assertEqual(supply.stat().st_mode & 0o777, 0o600)
        with sqlite3.connect(supply) as db:
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 0)
            self.assertEqual(db.execute("SELECT data FROM shared WHERE name='catalog'").fetchone()[0], "[]")
        retry = subprocess.run(
            ["php", str(site / "tools/setup-supply.php")],
            capture_output=True, text=True, env=self.env, timeout=30,
        )
        self.assertNotEqual(retry.returncode, 0)
        self.assertIn("will not be overwritten", retry.stderr)

        router = site / "router.php"
        router.write_text(
            "<?php $_SERVER['HTTPS'] = 'on'; "
            "if (parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) === '/api.php') "
            "{ require __DIR__ . '/public_html/api.php'; return true; } return false;"
        )
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        server = subprocess.Popen(
            ["php", "-S", "127.0.0.1:" + str(port), "-t", str(site / "public_html"), str(router)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=self.env,
        )
        try:
            for _ in range(100):
                if server.poll() is not None:
                    self.fail("PHP test server exited")
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=1):
                        break
                except OSError:
                    time.sleep(0.05)
            else:
                self.fail("PHP test server did not start")

            client = {"instance": secrets.token_hex(32)}

            def request(action, body=None):
                headers = {"X-Smartlist-Instance": client["instance"]}
                if "cookie" in client:
                    headers["Cookie"] = client["cookie"]
                if body is not None:
                    headers["Content-Type"] = "application/json"
                    headers["X-CSRF-Token"] = client["csrf"]
                conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
                conn.request("GET" if body is None else "POST", "/api.php?action=" + action,
                             body=None if body is None else json.dumps(body), headers=headers)
                response = conn.getresponse()
                cookie = response.getheader("Set-Cookie")
                if cookie:
                    client["cookie"] = cookie.split(";", 1)[0]
                result = json.loads(response.read())
                status = response.status
                conn.close()
                self.assertEqual(status, 200, (action, result))
                return result

            session = request("session")
            client["csrf"] = session["csrf"]
            login = request("login", {"username": ADMIN, "password": PASSWORD})
            client["csrf"] = login["csrf"]
            initial = request("load", {})
            self.assertTrue(initial["isAdmin"])
            self.assertIsNone(initial["state"])
            workspace = {"spaces": [{"id": "space"}],
                         "documents": [{"id": "project", "title": "Test", "nodes": []}]}
            self.assertEqual(request("save", {"revision": 0, "state": workspace})["revision"], 1)
            self.assertEqual(request("load", {})["state"]["documents"][0]["title"], "Test")
            request("account-extensions", {
                "userId": initial["userId"], "pmEnabled": True, "supplyEnabled": True,
                "walkthroughEnabled": True, "filesEnabled": True, "continuumEnabled": True,
                "supplyRole": "manager",
            })
            self.assertEqual(request("supply-state", {})["catalog"]["data"], [])
            self.assertEqual(request("shared-tracker-load", {})["state"]["tasks"], [])
            self.assertEqual(request("walkthrough-state", {})["walkthroughs"], [])
            self.assertEqual(request("files-list", {})["files"], [])
            self.assertIsNone(request("continuum-load", {})["state"])
        finally:
            server.terminate()
            server.wait(timeout=10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
