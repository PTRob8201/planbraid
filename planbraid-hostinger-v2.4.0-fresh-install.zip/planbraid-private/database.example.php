<?php
return [
    'host' => 'localhost',
    'database' => 'REPLACE_DATABASE_NAME',
    'username' => 'REPLACE_DATABASE_USER',
    'password' => 'REPLACE_DATABASE_PASSWORD',
];
