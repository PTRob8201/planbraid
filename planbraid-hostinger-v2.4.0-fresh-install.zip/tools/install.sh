#!/bin/sh
set +x
set -eu

cd "$(dirname "$0")"
if [ ! -t 0 ]; then
    echo "An interactive SSH terminal is required." >&2
    exit 1
fi
if ! command -v php >/dev/null 2>&1 || ! command -v stty >/dev/null 2>&1; then
    echo "The PHP CLI and stty are required." >&2
    exit 1
fi

printf 'Administrator username (3-80 letters, numbers, underscores, or hyphens): '
IFS= read -r username || exit 1
terminal=$(stty -g)
trap 'stty "$terminal" <&0' 0
trap 'exit 1' HUP INT TERM
stty -echo
printf 'Administrator password (12-72 bytes): '
IFS= read -r password || exit 1
printf '\nRepeat password: '
IFS= read -r confirmation || exit 1
stty "$terminal"
trap - 0 HUP INT TERM
printf '\n'

printf '%s\n%s\n%s\n' "$username" "$password" "$confirmation" | php ./setup.php --stdin
unset password confirmation

echo 'Creating the empty Supply database...'
php ./setup-supply.php
echo 'Creating and verifying the remaining tables...'
php ./migrate-onboarding.php
php ./migrate-walkthrough-files.php
php ./migrate-continuum.php
echo 'Importing the verified DB-IP country dataset; this can take several minutes...'
php ./import-country-data.php ./dbip-country-lite-2026-11.csv.gz
echo 'Fresh installation complete. Verify HTTPS, sign in, and test the enabled extensions.'
