<?php
/*
 * PlanBraid - outlining, project tracking, and material orders.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 * Licensed under GNU AGPL version 3 or later; see LICENSE in the release root.
 * Distributed WITHOUT ANY WARRANTY, including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if ($argc !== 2 || $argv[1] !== '--stdin') {
    fwrite(STDERR, "Run install.sh in an interactive terminal instead.\n");
    exit(1);
}
if (PHP_VERSION_ID < 80100) {
    throw new RuntimeException('PHP 8.1 or later is required.');
}
foreach (['pdo_mysql', 'pdo_sqlite', 'mbstring', 'zlib', 'fileinfo'] as $extension) {
    if (!extension_loaded($extension)) {
        throw new RuntimeException("The PHP $extension extension is required.");
    }
}
$root = dirname(__DIR__);
$rootDir = realpath($root);
$webRoot = realpath($root . '/public_html');
$privateDir = realpath($root . '/planbraid-private');
$toolsDir = realpath(__DIR__);
if ($rootDir === false || $webRoot === false || $privateDir === false || $toolsDir === false ||
    !is_dir($webRoot) || !is_dir($privateDir) ||
    in_array('public_html', explode(DIRECTORY_SEPARATOR, $rootDir), true) ||
    str_starts_with($privateDir . '/', $webRoot . '/') ||
    str_starts_with($toolsDir . '/', $webRoot . '/')) {
    throw new RuntimeException('public_html, planbraid-private, and tools must be sibling directories; private files and tools must be outside the web root.');
}
if (!is_writable($privateDir)) {
    throw new RuntimeException('The private directory must be writable by the installer and the PHP web process.');
}
$supplyPath = $privateDir . '/supply.sqlite';
if (file_exists($supplyPath) || is_link($supplyPath)) {
    throw new RuntimeException('A Supply database already exists; fresh installation stopped without changing it.');
}
$configFile = $privateDir . '/database.php';
if (!is_file($configFile)) {
    throw new RuntimeException('Create planbraid-private/database.php from the supplied example first.');
}
$config = require $configFile;
foreach (['host', 'database', 'username', 'password'] as $key) {
    if (!is_array($config) || !isset($config[$key]) || !is_string($config[$key]) ||
        $config[$key] === '' || str_starts_with($config[$key], 'REPLACE_')) {
        throw new RuntimeException("Set a nonempty $key in the private database configuration.");
    }
}
$username = trim((string) fgets(STDIN));
$password = rtrim((string) fgets(STDIN), "\r\n");
$confirmation = rtrim((string) fgets(STDIN), "\r\n");
if (!preg_match('/\A[a-zA-Z0-9_-]{3,80}\z/', $username)) {
    throw new RuntimeException('Invalid administrator username.');
}
if (strlen($password) < 12 || strlen($password) > 72 ||
    str_contains($password, "\0") || !hash_equals($password, $confirmation)) {
    throw new RuntimeException('Administrator passwords do not match or are not 12-72 bytes.');
}

$db = new PDO(
    'mysql:host=' . $config['host'] . ';dbname=' . $config['database'] . ';charset=utf8mb4',
    $config['username'],
    $config['password'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
);

$lock = $db->prepare('SELECT GET_LOCK(?, 0)');
$lock->execute(['planbraid-setup-' . substr(hash('sha256', $config['database']), 0, 32)]);
if ((int) $lock->fetchColumn() !== 1) {
    throw new RuntimeException('Another PlanBraid installation is already running.');
}
if ($db->query('SHOW FULL TABLES')->fetch(PDO::FETCH_NUM) !== false) {
    throw new RuntimeException('The MySQL database is not empty; fresh installation stopped without changing it.');
}

$db->exec('CREATE TABLE IF NOT EXISTS sl_users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$db->exec('CREATE TABLE IF NOT EXISTS sl_workspaces (
    user_id INT UNSIGNED NOT NULL PRIMARY KEY,
    revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
    data LONGTEXT NOT NULL,
    CONSTRAINT sl_workspace_user FOREIGN KEY (user_id) REFERENCES sl_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$db->exec('CREATE TABLE IF NOT EXISTS sl_continuum_workspaces (
    user_id INT UNSIGNED NOT NULL PRIMARY KEY,
    revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
    data LONGTEXT NOT NULL,
    CONSTRAINT sl_continuum_user FOREIGN KEY (user_id) REFERENCES sl_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$db->exec('CREATE TABLE IF NOT EXISTS sl_shared_tracker (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    version BIGINT UNSIGNED NOT NULL,
    data LONGTEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$db->exec('CREATE TABLE IF NOT EXISTS sl_account_access (
    user_id INT UNSIGNED NOT NULL PRIMARY KEY,
    is_admin TINYINT UNSIGNED NOT NULL DEFAULT 0,
    enabled TINYINT UNSIGNED NOT NULL DEFAULT 1,
    auth_version BIGINT UNSIGNED NOT NULL DEFAULT 0,
    active_instance_token CHAR(64) NULL,
    email VARCHAR(254) NULL,
    must_change_password TINYINT UNSIGNED NOT NULL DEFAULT 0,
    guide_seen TINYINT UNSIGNED NOT NULL DEFAULT 0,
    pm_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
    supply_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
    walkthrough_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
    files_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
    continuum_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
    supply_role VARCHAR(12) NOT NULL DEFAULT \'technician\',
    personal_project_pending TINYINT UNSIGNED NOT NULL DEFAULT 1,
    CONSTRAINT sl_access_user FOREIGN KEY (user_id) REFERENCES sl_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$db->exec("CREATE TABLE IF NOT EXISTS sl_walkthroughs (
    id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
    version BIGINT UNSIGNED NOT NULL,
    data LONGTEXT NOT NULL,
    created_by INT UNSIGNED NULL,
    updated_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY sl_walkthroughs_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS sl_files (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(240) NOT NULL,
    mime_type VARCHAR(80) NOT NULL,
    size_bytes INT UNSIGNED NOT NULL,
    folder VARCHAR(120) NOT NULL DEFAULT '',
    data MEDIUMBLOB NOT NULL,
    walkthrough_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
    walkthrough_item_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
    uploaded_by INT UNSIGNED NULL,
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY sl_files_walkthrough (walkthrough_id, walkthrough_item_id, uploaded_at),
    KEY sl_files_folder (folder),
    CONSTRAINT sl_files_walkthrough_fk FOREIGN KEY (walkthrough_id)
        REFERENCES sl_walkthroughs (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec('CREATE TABLE IF NOT EXISTS sl_login_attempts (
    client_hash CHAR(64) CHARACTER SET ascii NOT NULL PRIMARY KEY,
    attempts INT UNSIGNED NOT NULL,
    expires_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

$db->beginTransaction();
try {
    $db->query('SELECT id FROM sl_users FOR UPDATE')->fetchAll();
    if ((int) $db->query('SELECT COUNT(*) FROM sl_users')->fetchColumn() !== 0) {
        throw new RuntimeException('An account already exists.');
    }
    $statement = $db->prepare('INSERT INTO sl_users (username, password_hash) VALUES (?, ?)');
    $hash = password_hash($password, PASSWORD_DEFAULT);
    if ($hash === false) throw new RuntimeException('Password hashing failed.');
    unset($password, $confirmation);
    $statement->execute([$username, $hash]);
    $db->prepare('INSERT INTO sl_account_access (user_id, is_admin, enabled, auth_version) VALUES (?, 1, 1, 0)')->execute([(int) $db->lastInsertId()]);
    $db->commit();
    fwrite(STDOUT, "Administrator account created.\n");
} catch (Throwable $error) {
    $db->rollBack();
    throw $error;
}
