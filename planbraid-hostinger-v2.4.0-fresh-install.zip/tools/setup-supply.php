<?php
/*
 * PlanBraid - outlining, project tracking, and material orders.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$root = realpath(dirname(__DIR__));
$webRoot = realpath(dirname(__DIR__) . '/public_html');
$privateDir = realpath(dirname(__DIR__) . '/planbraid-private');
if ($root === false || $webRoot === false || $privateDir === false ||
    in_array('public_html', explode(DIRECTORY_SEPARATOR, $root), true) ||
    str_starts_with($privateDir . '/', $webRoot . '/') ||
    str_starts_with(realpath(__DIR__) . '/', $webRoot . '/')) {
    throw new RuntimeException('The private directory and tools must be outside the web root.');
}
$path = $privateDir . '/supply.sqlite';
if (!is_dir($privateDir) || !is_writable($privateDir)) {
    throw new RuntimeException('The private directory must exist and be writable.');
}
if (file_exists($path) || is_link($path)) {
    throw new RuntimeException('A Supply database already exists; it will not be overwritten.');
}

$oldMask = umask(0077);
try {
    $file = fopen($path, 'x');
} finally {
    umask($oldMask);
}
if ($file === false) {
    throw new RuntimeException('Unable to create the Supply database.');
}
fclose($file);

$db = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$db->exec('PRAGMA foreign_keys = ON');
$db->beginTransaction();
try {
    $db->exec('CREATE TABLE users (
        id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
    )');
    $db->exec('CREATE TABLE shared (name TEXT PRIMARY KEY, version INTEGER NOT NULL, data TEXT NOT NULL)');
    $db->exec('CREATE TABLE orders (
        id TEXT PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id),
        version INTEGER NOT NULL, data TEXT NOT NULL
    )');
    $statement = $db->prepare('INSERT INTO shared (name, version, data) VALUES (?, 1, ?)');
    $statement->execute(['settings', '{"categories":["General"],"units":["ea"],"defaultUnit":"ea"}']);
    $statement->execute(['catalog', '[]']);
    $db->commit();
    echo "Empty Supply database created.\n";
} catch (Throwable $error) {
    if ($db->inTransaction()) $db->rollBack();
    throw $error;
}
