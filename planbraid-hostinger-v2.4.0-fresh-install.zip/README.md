# PlanBraid v2.4.0: fresh Hostinger installation

This package sets up a **new, empty** PlanBraid site. It does not import an
existing installation or its data. For an existing site, use the separate
Hostinger upgrade package instead. Before any upgrade, verify backups of the
application files, private configuration, MySQL database, and Supply SQLite
database.

## Requirements

- Hostinger hosting with an HTTPS-enabled domain, SSH access, and an
  interactive terminal with `php` and `stty`.
- PHP 8.1 or later for both the website and CLI, with PDO MySQL, PDO SQLite,
  mbstring, fileinfo, and zlib enabled. PHP sessions must work.
- A new, empty MySQL/MariaDB database and a database user with all privileges
  on that database, including creating and altering tables.
- An empty site document root. Do not copy these files over an existing site.

The installer checks that the database has no tables and that no
`supply.sqlite` exists before creating anything. It does not delete or
overwrite an existing database. It creates one administrator; extensions are
disabled until the administrator enables them.

## Install

1. Extract the ZIP on your computer. In Hostinger hPanel, create the new
   database and database user. Note its host, database name, user and
   password; do not share or commit those credentials.
2. Locate the domain's directory, for example
   `~/domains/example.com/`. Upload the **contents** of this package's
   `public_html/` into its empty `public_html/`, including the hidden
   `.htaccess`. Upload `tools/` and `planbraid-private/` as siblings of
   `public_html/`, **not** inside the web root:

   ```text
   example.com/
   |-- public_html/              application files
   |-- planbraid-private/        configuration and Supply database
   `-- tools/                    temporary installer
   ```

   Do not extract the entire ZIP into `public_html/`. Verify the private
   directory is outside every document root and alias, including any parent
   site's web root.

3. In `planbraid-private/`, copy `database.example.php` to `database.php`
   and edit the copy with the database credentials from hPanel. Keep this file
   and the private directory outside the web root. Restrict access to the
   hosting account and PHP process; do not use world-writable permissions.
   The PHP process must be able to read `database.php` and read and write the
   private directory and its SQLite files. On hosts where SSH and PHP run as
   the same account, directory mode `700` and file mode `600` are suitable.
4. Connect by SSH, change into the uploaded `tools/` directory, and run:

   ```sh
   sh install.sh
   ```

   Enter the administrator username and password when prompted. The password
   must be 12-72 bytes and is not echoed. Do not put it in a command, shell
   history, or configuration file. The installer initializes MySQL and
   Supply, verifies the extension schemas, and imports the bundled country
   data. The import can take several minutes and needs database space for
   732,796 ranges.
5. Enable a valid TLS certificate and Hostinger's Force HTTPS. Check that the
   domain opens the landing page and the app opens at `index.html`. Sign in
   as the new administrator and save a test note. Enable Tasks, Supply,
   Walkthrough, Files, or Continuum for an account in **Manage accounts** and
   test the extensions you use. Supply starts with an empty catalog.
6. Confirm that the private directory, database configuration and SQLite
   database cannot be reached through the website; a request such as
   `/planbraid-private/database.php` should be denied or not found. If private
   files are accessible, take the site offline and change the database
   credentials before proceeding. Check the PHP error log, verify the License
   dialog downloads `planbraid-source.zip`, and delete the uploaded `tools/`
   directory after installation is accepted.

## If installation stops

Do not run the installer over an existing database. It deliberately refuses to
restart after tables or a Supply database have been created. Read the reported
error and check the PHP modules, database privileges, writable private
directory, available database space, and dataset import. For an interrupted
installation that has **never contained user data**, a server administrator
can recreate the dedicated empty database and remove the Supply file created
by the interrupted installation before starting again. Do not remove any
existing site or user data.

If only the country import failed after all preceding steps succeeded, resolve
the reported problem and rerun `php import-country-data.php
dbip-country-lite-2026-11.csv.gz` from `tools/`; the import is transactional.

## Source and attribution

`public_html/planbraid-source.zip` contains the corresponding application
source and installer. PlanBraid is licensed under the GNU AGPL v3 or later;
see `LICENSE`. The PlanBraid name and logo are not licensed under
the AGPL. The bundled DB-IP Country Lite data is by [DB-IP](https://db-ip.com),
licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

For development, `python3 tests/test_fresh_install.py` tests the installer
against temporary local MariaDB and SQLite databases using synthetic accounts.
It requires PHP, `mariadb-install-db`, `mariadbd`, and the MariaDB client tools.
