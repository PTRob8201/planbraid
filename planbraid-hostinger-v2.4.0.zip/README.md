# PlanBraid Hostinger upgrade v2.4.0

Updates an existing PlanBraid Hostinger installation (v2.2.0) to v2.4.0, matching
the home-server 2.4.0 release with Hostinger paths (private config in
`planbraid-private/`, PM and Supply under `public_html/extensions/`, cookie path `/`).

Before installing, back up `public_html` (including `.htaccess`), `planbraid-private`,
the MySQL database and `planbraid-private/supply.sqlite`, and verify the backups.

Install:
1. Upload `tools/` outside the web root (e.g. `domains/planbraid.com/planbraid-tools-2.4.0/`)
   and run, in order: `migrate-accounts.php`, `migrate-onboarding.php`,
   `migrate-walkthrough-files.php`, `migrate-continuum.php`, then
   `import-country-data.php dbip-country-lite-2026-11.csv.gz`. All are additive and rerunnable.
2. Copy the contents of `public_html/` over the live `public_html/`, preserving `.htaccess`.
3. Delete the uploaded `tools/` directory.

`tools/dump-database.php` needs `proc_open`, which Hostinger disables; back up with
`mysqldump` directly instead.
