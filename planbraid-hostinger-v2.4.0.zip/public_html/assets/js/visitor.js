/*!
 * PlanBraid - outlining, project tracking, and material orders.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
const countedVisitorPages = new Set();
async function trackPageView(page) {
    if (countedVisitorPages.has(page)) return;
    countedVisitorPages.add(page);
    try {
        const referral = document.referrer ? new URL(document.referrer).hostname : '';
        const response = await fetch('api.php?action=page-view', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ page, referral: referral.includes(':') ? '' : referral }),
            keepalive: true
        });
        if (!response.ok) throw new Error(`Statistics request failed (${response.status}).`);
    } catch (error) {
        console.error('Could not record page statistics:', error);
    }
}
if (document.currentScript.dataset.page === 'landing') trackPageView('landing');
