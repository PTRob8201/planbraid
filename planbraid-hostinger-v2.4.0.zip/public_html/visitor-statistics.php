<?php
/*
 * PlanBraid - outlining, project tracking, and material orders.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);

function visitorAddress(string $ip): array {
    $packed = inet_pton($ip);
    if ($packed === false) throw new InvalidArgumentException('Invalid visitor address.');
    if (strlen($packed) === 16 && substr($packed, 0, 12) === str_repeat("\0", 10) . "\xff\xff") {
        $packed = substr($packed, 12);
        $ip = inet_ntop($packed);
    }
    $family = strlen($packed) === 4 ? 4 : 6;
    $masked = $family === 4 ? substr($packed, 0, 3) . "\0" : substr($packed, 0, 6) . str_repeat("\0", 10);
    return [
        'family' => $family, 'packed' => str_pad($packed, 16, "\0", STR_PAD_LEFT),
        'masked' => inet_ntop($masked) . ($family === 4 ? '/24' : '/48'),
        'public' => filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false
    ];
}

function visitorCountry(PDO $db, array $address): string {
    if (!$address['public']) return 'local';
    $statement = $db->prepare('SELECT ip_end, country FROM sl_country_ranges WHERE family = ? AND ip_start <= ? ORDER BY ip_start DESC LIMIT 1');
    $statement->execute([$address['family'], $address['packed']]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return $row && strcmp($address['packed'], $row['ip_end']) <= 0 && $row['country'] !== 'ZZ' ? $row['country'] : 'unknown';
}

function visitorAgent(string $agent): array {
    $browser = match (true) {
        preg_match('/bot|crawler|spider|slurp/i', $agent) === 1 => 'Bot',
        preg_match('/Edg(?:e|A|iOS)?\//', $agent) === 1 => 'Edge',
        preg_match('/OPR\/|Opera/', $agent) === 1 => 'Opera',
        preg_match('/Firefox\/|FxiOS\//', $agent) === 1 => 'Firefox',
        preg_match('/Chrome\/|CriOS\//', $agent) === 1 => 'Chrome',
        str_contains($agent, 'Safari/') => 'Safari',
        preg_match('/MSIE |Trident\//', $agent) === 1 => 'Internet Explorer',
        default => 'Unknown'
    };
    $os = match (true) {
        preg_match('/iPad|iPhone|iPod/', $agent) === 1 => 'iOS',
        str_contains($agent, 'Android') => 'Android',
        str_contains($agent, 'Windows') => 'Windows',
        str_contains($agent, 'CrOS') => 'Chrome OS',
        str_contains($agent, 'Macintosh') => 'macOS',
        str_contains($agent, 'Linux') => 'Linux',
        default => 'Unknown'
    };
    $device = match (true) {
        $browser === 'Bot' => 'Bot',
        preg_match('/iPad|Tablet/i', $agent) === 1 || ($os === 'Android' && !str_contains($agent, 'Mobile')) => 'Tablet',
        preg_match('/Mobile|iPhone|iPod/i', $agent) === 1 => 'Mobile',
        $os !== 'Unknown' => 'Desktop',
        default => 'Unknown'
    };
    return ['browser' => $browser, 'os' => $os, 'device' => $device];
}

function visitorReferral(mixed $domain): string {
    if ($domain === '') return '';
    if (!is_string($domain) || strlen($domain) > 253 ||
        filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) === false) {
        throw new InvalidArgumentException('Invalid referral domain.');
    }
    if (filter_var($domain, FILTER_VALIDATE_IP) !== false) return '';
    return strtolower($domain);
}
