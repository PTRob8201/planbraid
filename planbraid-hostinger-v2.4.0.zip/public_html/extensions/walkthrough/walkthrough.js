/*
 * PlanBraid Walkthrough
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
(() => {
    const api = window.parent.api;
    const maxFileBytes = 3 * 1024 * 1024;
    let records = [];
    let current = null;
    let uploadBusy = false;
    let currentAttachments = [];
    let photoCaptions = {};
    let attachmentObjectUrls = new Map();
    let attachmentLoadGeneration = 0;
    const byId = id => document.getElementById(id);
    const uuid = () => crypto.randomUUID();

    function setStatus(message, error = false) {
        byId('form-status').textContent = message;
        byId('form-status').dataset.state = error ? 'error' : '';
        byId('save-status').textContent = message;
        if (byId('report-preview').open) {
            const previewStatus = byId('preview-status');
            previewStatus.hidden = false;
            previewStatus.textContent = message;
            previewStatus.dataset.state = error ? 'error' : '';
        }
    }

    function today() {
        const now = new Date();
        return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    }

    function emptyData() {
        return {
            customer: '', site: '', address: '', contactName: '', contactPhone: '',
            lead: '', date: today(), areas: [], systems: [], issues: []
        };
    }

    function setEditorVisible(open) {
        byId('list-view').hidden = open;
        byId('editor-view').hidden = !open;
        byId('new-walkthrough').hidden = open;
        if (open) window.scrollTo(0, 0);
    }

    function renderList() {
        const list = byId('walkthrough-list');
        list.replaceChildren();
        byId('empty-state').hidden = records.length > 0;
        records.forEach(record => {
            const card = document.createElement('article');
            card.className = 'walkthrough-card';
            const open = document.createElement('button');
            open.type = 'button';
            open.className = 'walkthrough-open';
            const summary = document.createElement('span');
            const title = document.createElement('h3');
            title.textContent = record.data.site;
            const customer = document.createElement('p');
            customer.textContent = record.data.customer;
            summary.append(title, customer);
            const meta = document.createElement('span');
            meta.className = 'walkthrough-meta';
            meta.textContent = [record.data.date || 'Date not set', `${record.data.issues.length} action items`].join(' · ');
            open.append(summary, meta);
            open.addEventListener('click', () => openRecord(record));
            const actions = document.createElement('div');
            actions.className = 'walkthrough-card-actions';
            [['PDF', 'save-report-pdf'], ['PNG', 'download-report-png']].forEach(([label, target]) => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'button';
                button.textContent = label;
                button.setAttribute('aria-label', `Preview ${record.data.site} report for ${label}`);
                button.addEventListener('click', () => {
                    openRecord(record, false);
                    openReportPreview(target);
                });
                actions.appendChild(button);
            });
            card.append(open, actions);
            list.appendChild(card);
        });
        byId('save-status').textContent = records.length ? `${records.length} walkthrough${records.length === 1 ? '' : 's'}` : 'Ready';
    }

    function addArea(area = { id: uuid(), name: '', notes: '' }) {
        const fragment = byId('area-template').content.cloneNode(true);
        const entry = fragment.querySelector('.area-entry');
        entry.dataset.id = area.id;
        entry.querySelector('.area-name').value = area.name;
        entry.querySelector('.area-notes').value = area.notes;
        const photoInput = entry.querySelector('.area-photo-input');
        photoInput.disabled = current.version === 0 || uploadBusy;
        photoInput.addEventListener('change', () => {
            if (photoInput.files?.length) uploadAttachments(Array.from(photoInput.files), entry.dataset.id, photoInput);
        });
        entry.querySelector('.remove-entry').addEventListener('click', () => {
            entry.remove();
            refreshAttachmentTargets();
            updateEmptyHints();
        });
        entry.querySelector('.remove-entry').hidden = !current.canEdit;
        byId('area-list').appendChild(fragment);
        updateEmptyHints();
    }

    function addIssue(issue = { id: uuid(), title: '', area: '', priority: 'normal', status: 'open', dueDate: '', action: '' }) {
        const fragment = byId('issue-template').content.cloneNode(true);
        const entry = fragment.querySelector('.issue-entry');
        entry.dataset.id = issue.id;
        entry.querySelector('.issue-title').value = issue.title;
        entry.querySelector('.issue-area').value = issue.area;
        entry.querySelector('.issue-priority').value = issue.priority;
        entry.querySelector('.issue-status').value = issue.status;
        entry.querySelector('.issue-due').value = issue.dueDate;
        entry.querySelector('.issue-action').value = issue.action;
        entry.querySelector('.remove-entry').addEventListener('click', () => {
            entry.remove();
            refreshAttachmentTargets();
            updateEmptyHints();
        });
        entry.querySelector('.remove-entry').hidden = !current.canEdit;
        byId('issue-list').appendChild(fragment);
        updateEmptyHints();
    }

    function updateEmptyHints() {
        byId('areas-empty').hidden = byId('area-list').children.length > 0;
        byId('issues-empty').hidden = byId('issue-list').children.length > 0;
        updateAreaReportVisibility();
    }

    function updateAreaReportVisibility() {
        const areaEntries = Array.from(byId('area-list').querySelectorAll('.area-entry'));
        areaEntries.forEach(entry => {
            const hasNotes = entry.querySelector('.area-notes').value.trim() !== '';
            const hasFiles = currentAttachments.some(file => file.walkthroughItemId === entry.dataset.id);
            entry.dataset.reportEmpty = String(!hasNotes && !hasFiles);
        });
        const hasReportAreas = areaEntries.some(entry => entry.dataset.reportEmpty === 'false');
        byId('areas-section').dataset.reportEmpty = String(!hasReportAreas);
    }

    function refreshAttachmentTargets() {
        const select = byId('attachment-link');
        const selected = select.value;
        select.replaceChildren(new Option('Site overview', ''));
        byId('area-list').querySelectorAll('.area-entry').forEach((entry, index) => {
            const label = entry.querySelector('.area-name').value.trim() || `Area ${index + 1}`;
            select.add(new Option(`Area: ${label}`, entry.dataset.id));
        });
        byId('issue-list').querySelectorAll('.issue-entry').forEach((entry, index) => {
            const label = entry.querySelector('.issue-title').value.trim() || `Issue ${index + 1}`;
            select.add(new Option(`Action: ${label}`, entry.dataset.id));
        });
        if (Array.from(select.options).some(option => option.value === selected)) select.value = selected;
    }

    function renderEditor(loadFiles = true) {
        const data = current.data;
        revokeAttachmentObjectUrls();
        currentAttachments = [];
        photoCaptions = { ...data.photoCaptions };
        byId('customer').value = data.customer;
        byId('site').value = data.site;
        byId('walkthrough-date').value = data.date;
        byId('lead').value = data.lead;
        byId('contact-name').value = data.contactName;
        byId('contact-phone').value = data.contactPhone;
        byId('address').value = data.address;
        byId('report-title').textContent = data.site || 'New site walkthrough';
        byId('delete-walkthrough').hidden = current.version === 0;
        byId('area-list').replaceChildren();
        data.areas.forEach(addArea);
        byId('issue-list').replaceChildren();
        data.issues.forEach(addIssue);
        const readOnly = !current.canEdit;
        ['.report-header', '#area-list', '#issue-list'].forEach(selector => {
            document.querySelectorAll(`${selector} input:not([type="file"]), ${selector} select, ${selector} textarea`).forEach(control => {
                control.disabled = readOnly;
            });
        });
        byId('add-area').hidden = readOnly;
        byId('add-issue').hidden = readOnly;
        byId('save-walkthrough').disabled = readOnly;
        byId('attachment-input').disabled = current.version === 0 || uploadBusy;
        byId('delete-walkthrough').hidden = current.version === 0 || readOnly;
        byId('attachments-empty').hidden = current.version > 0;
        refreshAttachmentTargets();
        updateEmptyHints();
        setStatus(readOnly ? 'View only. Only the creator or a PlanBraid administrator can edit or delete this walkthrough.'
            : current.version === 0 ? 'New walkthrough — save before adding files.' : 'All changes saved.');
        if (loadFiles) loadAttachments().catch(error => setStatus(`Could not load attachments: ${error.message}`, true));
    }

    function openRecord(record, loadFiles = true) {
        current = structuredClone(record);
        setEditorVisible(true);
        renderEditor(loadFiles);
    }

    function newRecord() {
        current = { id: uuid(), version: 0, canEdit: true, data: emptyData() };
        setEditorVisible(true);
        renderEditor();
        byId('customer').focus();
    }

    function collectData() {
        return {
            customer: byId('customer').value.trim(),
            site: byId('site').value.trim(),
            address: byId('address').value.trim(),
            contactName: byId('contact-name').value.trim(),
            contactPhone: byId('contact-phone').value.trim(),
            lead: byId('lead').value.trim(),
            date: byId('walkthrough-date').value,
            areas: Array.from(byId('area-list').querySelectorAll('.area-entry'), entry => ({
                id: entry.dataset.id,
                name: entry.querySelector('.area-name').value.trim(),
                applicable: true,
                notes: entry.querySelector('.area-notes').value.trim()
            })),
            systems: current.data.systems,
            photoCaptions: { ...photoCaptions },
            issues: Array.from(byId('issue-list').querySelectorAll('.issue-entry'), entry => ({
                id: entry.dataset.id,
                title: entry.querySelector('.issue-title').value.trim(),
                area: entry.querySelector('.issue-area').value.trim(),
                priority: entry.querySelector('.issue-priority').value,
                status: entry.querySelector('.issue-status').value,
                dueDate: entry.querySelector('.issue-due').value,
                action: entry.querySelector('.issue-action').value.trim()
            }))
        };
    }

    function hasUnsavedChanges() {
        if (!current?.canEdit) return false;
        const original = current.data;
        const baseline = {
            customer: original.customer.trim(), site: original.site.trim(), address: original.address.trim(),
            contactName: original.contactName.trim(), contactPhone: original.contactPhone.trim(),
            lead: original.lead.trim(), date: original.date,
            areas: original.areas.map(area => ({
                id: area.id, name: area.name.trim(), applicable: true, notes: area.notes.trim()
            })),
            systems: original.systems,
            photoCaptions: { ...original.photoCaptions },
            issues: original.issues.map(issue => ({
                id: issue.id, title: issue.title.trim(), area: issue.area.trim(), priority: issue.priority,
                status: issue.status, dueDate: issue.dueDate, action: issue.action.trim()
            }))
        };
        return JSON.stringify(collectData()) !== JSON.stringify(baseline);
    }

    async function saveRecord() {
        if (!current?.canEdit) {
            setStatus('Only the walkthrough creator or a PlanBraid administrator can edit it.', true);
            return false;
        }
        const data = collectData();
        if (!data.customer || !data.site || !data.lead) {
            setStatus('Customer, site name, and walkthrough lead are required.', true);
            byId(!data.customer ? 'customer' : !data.site ? 'site' : 'lead').focus();
            return false;
        }
        if (data.areas.some(area => !area.name) || data.issues.some(issue => !issue.title)) {
            setStatus('Every area needs a name, and every action item needs a title.', true);
            return false;
        }
        if (Object.values(data.photoCaptions).some(caption => new TextEncoder().encode(caption).length > 200)) {
            setStatus('Photo captions must be at most 200 bytes. Shorten the caption and try again.', true);
            return false;
        }
        byId('save-walkthrough').disabled = true;
        setStatus('Saving walkthrough…');
        try {
            const result = await api('walkthrough-save', { id: current.id, version: current.version, data });
            current = { ...current, version: result.version, data };
            const index = records.findIndex(record => record.id === current.id);
            if (index < 0) records.unshift(current);
            else records[index] = current;
            byId('report-title').textContent = data.site;
            byId('delete-walkthrough').hidden = false;
            byId('attachment-input').disabled = false;
            byId('area-list').querySelectorAll('.area-photo-input').forEach(input => { input.disabled = uploadBusy; });
            byId('attachments-empty').hidden = true;
            refreshAttachmentTargets();
            renderList();
            setStatus('Walkthrough saved.');
            return true;
        } catch (error) {
            setStatus(`Could not save walkthrough: ${error.message}`, true);
            return false;
        } finally {
            byId('save-walkthrough').disabled = false;
        }
    }

    function formatBytes(bytes) {
        return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    }

    function blobFromBase64(data, mimeType) {
        const binary = atob(data);
        const bytes = new Uint8Array(binary.length);
        for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
        return new Blob([bytes], { type: mimeType });
    }

    function revokeAttachmentObjectUrls() {
        attachmentObjectUrls.forEach(url => URL.revokeObjectURL(url));
        attachmentObjectUrls.clear();
    }

    function downloadUrl(url, filename) {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.style.position = 'fixed';
        link.style.left = '-10000px';
        (document.querySelector('dialog[open]') || document.body).appendChild(link);
        link.click();
        link.remove();
    }

    function createDownload(data, filename, mimeType) {
        const url = URL.createObjectURL(blobFromBase64(data, mimeType));
        downloadUrl(url, filename);
        setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    function downloadBlob(blob, filename) {
        const url = URL.createObjectURL(blob);
        downloadUrl(url, filename);
        setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    async function addPhotoCard(file, context, url, grid) {
        const figure = document.createElement('figure');
        figure.className = 'photo-card';
        const image = document.createElement('img');
        image.src = url;
        image.alt = `${context}: ${file.filename}`;
        image.loading = 'eager';
        const caption = document.createElement('figcaption');
        const updateCaption = () => {
            caption.textContent = `${context} · ${photoCaptions[file.id] || file.filename}`;
        };
        updateCaption();
        const actions = document.createElement('div');
        actions.className = 'photo-actions';
        if (current.canEdit) {
            const label = document.createElement('label');
            label.className = 'photo-caption-label';
            label.textContent = 'Photo caption';
            const input = document.createElement('input');
            input.className = 'photo-caption-input';
            input.maxLength = 200;
            input.value = photoCaptions[file.id] || '';
            input.placeholder = file.filename;
            input.addEventListener('input', () => {
                const value = input.value.trim();
                if (value) photoCaptions[file.id] = value;
                else delete photoCaptions[file.id];
                updateCaption();
            });
            label.appendChild(input);
            actions.appendChild(label);
        }
        const download = document.createElement('button');
        download.type = 'button';
        download.className = 'button';
        download.textContent = 'Download';
        download.addEventListener('click', () => downloadUrl(url, file.filename));
        actions.appendChild(download);
        if (file.canDelete) {
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'button button-danger';
            remove.textContent = 'Remove';
            remove.addEventListener('click', () => removeAttachment(file, remove));
            actions.appendChild(remove);
        }
        figure.append(image, caption, actions);
        grid.appendChild(figure);
        try {
            if (typeof image.decode === 'function') await image.decode();
            else if (!image.complete) {
                await new Promise((resolve, reject) => {
                    image.addEventListener('load', resolve, { once: true });
                    image.addEventListener('error', () => reject(new Error('The image could not be decoded.')), { once: true });
                });
            }
            if (!image.naturalWidth) throw new Error('The image could not be decoded.');
        } catch (error) {
            figure.remove();
            throw error;
        }
    }

    async function removeAttachment(file, button) {
        if (!confirm(`Remove ${file.filename} from this walkthrough?`)) return;
        button.disabled = true;
        try {
            await api('files-delete', { id: file.id });
            await loadAttachments();
            setStatus('Attachment removed.');
        } catch (error) {
            setStatus(`Could not remove file: ${error.message}`, true);
            button.disabled = false;
        }
    }

    async function loadAttachments() {
        const generation = ++attachmentLoadGeneration;
        revokeAttachmentObjectUrls();
        currentAttachments = [];
        const list = byId('attachment-list');
        list.replaceChildren();
        byId('editor-view').querySelectorAll('.photo-grid').forEach(grid => grid.replaceChildren());
        byId('editor-view').querySelectorAll('.area-photos, .issue-photos').forEach(section => { section.hidden = true; });
        if (!current || current.version === 0) {
            updateAreaReportVisibility();
            return true;
        }
        const walkthroughId = current.id;
        const result = await api('files-list', { walkthroughId: current.id });
        if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
        currentAttachments = result.files;
        let photoLoadFailed = false;
        const nestedPhotoIds = new Set();
        const areaEntries = Array.from(byId('area-list').querySelectorAll('.area-entry'));
        const issueEntries = Array.from(byId('issue-list').querySelectorAll('.issue-entry'));

        for (const entry of areaEntries) {
            const section = entry.querySelector('.area-photos');
            const grid = section.querySelector('.photo-grid');
            grid.replaceChildren();
            const areaName = entry.querySelector('.area-name').value.trim();
            const linkedPhotos = result.files.filter(file =>
                file.walkthroughItemId === entry.dataset.id && file.mimeType.startsWith('image/'));
            for (const file of linkedPhotos) {
                if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
                try {
                    const contents = await api('files-download', { id: file.id });
                    if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
                    const url = URL.createObjectURL(blobFromBase64(contents.data, contents.mimeType));
                    attachmentObjectUrls.set(file.id, url);
                    await addPhotoCard(file, `Area: ${areaName}`, url, grid);
                    nestedPhotoIds.add(file.id);
                } catch (error) {
                    if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
                    photoLoadFailed = true;
                    const url = attachmentObjectUrls.get(file.id);
                    if (url) URL.revokeObjectURL(url);
                    attachmentObjectUrls.delete(file.id);
                    setStatus(`Could not load photo ${file.filename}: ${error.message}`, true);
                }
            }
            section.hidden = grid.children.length === 0;
        }

        for (const entry of issueEntries) {
            const section = entry.querySelector('.issue-photos');
            const grid = section.querySelector('.photo-grid');
            grid.replaceChildren();
            const issueTitle = entry.querySelector('.issue-title').value.trim();
            const linkedPhotos = result.files.filter(file =>
                file.walkthroughItemId === entry.dataset.id && file.mimeType.startsWith('image/'));
            for (const file of linkedPhotos) {
                if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
                try {
                    const contents = await api('files-download', { id: file.id });
                    if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
                    const url = URL.createObjectURL(blobFromBase64(contents.data, contents.mimeType));
                    attachmentObjectUrls.set(file.id, url);
                    await addPhotoCard(file, `Action: ${issueTitle}`, url, grid);
                    nestedPhotoIds.add(file.id);
                } catch (error) {
                    if (generation !== attachmentLoadGeneration || current?.id !== walkthroughId) return false;
                    photoLoadFailed = true;
                    const url = attachmentObjectUrls.get(file.id);
                    if (url) URL.revokeObjectURL(url);
                    attachmentObjectUrls.delete(file.id);
                    setStatus(`Could not load photo ${file.filename}: ${error.message}`, true);
                }
            }
            section.hidden = grid.children.length === 0;
        }

        result.files.filter(file => !nestedPhotoIds.has(file.id)).forEach(file => {
            const row = document.createElement('div');
            row.className = 'file-row';
            const name = document.createElement('span');
            name.className = 'file-name';
            name.textContent = file.filename;
            const item = document.createElement('span');
            item.className = 'file-meta';
            item.textContent = file.walkthroughItemId
                ? (current.data.areas.find(area => area.id === file.walkthroughItemId)?.name ||
                    current.data.issues.find(issue => issue.id === file.walkthroughItemId)?.title || 'Linked item')
                : 'Site overview';
            const download = document.createElement('button');
            download.type = 'button';
            download.className = 'button';
            download.textContent = 'Download';
            download.addEventListener('click', async () => {
                download.disabled = true;
                try {
                    const contents = await api('files-download', { id: file.id });
                    createDownload(contents.data, contents.filename, contents.mimeType);
                } catch (error) {
                    setStatus(`Could not download file: ${error.message}`, true);
                } finally {
                    download.disabled = false;
                }
            });
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'text-button';
            remove.textContent = 'Remove';
            remove.hidden = !file.canDelete;
            remove.addEventListener('click', () => removeAttachment(file, remove));
            row.append(name, item, download, remove);
            list.appendChild(row);
        });
        updateAreaReportVisibility();
        if (result.files.length) {
            byId('attachments-empty').hidden = true;
        } else {
            byId('attachments-empty').textContent = current.version === 0
                ? 'Save the walkthrough before attaching files. Each file may be up to 3 MB.'
                : 'No files are linked to this walkthrough yet.';
            byId('attachments-empty').hidden = false;
        }
        return !photoLoadFailed;
    }

    function renderReportPreview() {
        const report = document.createElement('div');
        report.className = 'report-preview-document';
        document.querySelectorAll('#editor-view > .report-header, #editor-view > .report-section')
            .forEach(section => {
                const copy = section.cloneNode(true);
                const originals = section.querySelectorAll('input, select, textarea');
                copy.querySelectorAll('input, select, textarea').forEach((control, index) => {
                    control.value = originals[index].value;
                });
                report.appendChild(copy);
            });
        report.querySelectorAll('button, .file-picker, .upload-row, .empty-hint, .photo-actions')
            .forEach(element => element.remove());
        report.querySelectorAll('input, select, textarea').forEach(control => {
            const value = control.tagName === 'SELECT'
                ? control.selectedOptions[0]?.textContent.trim()
                : control.value.trim();
            const text = document.createElement(control.tagName === 'TEXTAREA' ? 'div' : 'span');
            text.className = 'report-value';
            text.textContent = value || '—';
            control.replaceWith(text);
        });
        byId('report-preview-content').replaceChildren(report);
    }

    async function reportPreviewPng() {
        const report = byId('report-preview-content').firstElementChild;
        if (!report) throw new Error('The report preview is empty.');
        const width = Math.ceil(report.scrollWidth);
        const height = Math.ceil(report.scrollHeight);
        if (!width || !height) throw new Error('The report preview has no visible content.');
        const scale = Math.min(
            2,
            32767 / width,
            32767 / height,
            Math.sqrt(16000000 / (width * height))
        );
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.floor(width * scale));
        canvas.height = Math.max(1, Math.floor(height * scale));
        const context = canvas.getContext('2d');
        if (!context) throw new Error('PNG rendering is unavailable in this browser.');
        context.scale(scale, scale);
        context.fillStyle = '#fff';
        context.fillRect(0, 0, width, height);

        const reportBounds = report.getBoundingClientRect();
        const visibleRect = element => {
            const style = getComputedStyle(element);
            if (style.display === 'none' || style.visibility === 'hidden') return null;
            const rect = element.getBoundingClientRect();
            return rect.width && rect.height ? rect : null;
        };
        const drawRoundedRect = (x, y, rectWidth, rectHeight, radius) => {
            const r = Math.min(radius, rectWidth / 2, rectHeight / 2);
            context.beginPath();
            context.moveTo(x + r, y);
            context.arcTo(x + rectWidth, y, x + rectWidth, y + rectHeight, r);
            context.arcTo(x + rectWidth, y + rectHeight, x, y + rectHeight, r);
            context.arcTo(x, y + rectHeight, x, y, r);
            context.arcTo(x, y, x + rectWidth, y, r);
            context.closePath();
        };
        const elements = [report, ...report.querySelectorAll('*')];
        elements.forEach(element => {
            const rect = visibleRect(element);
            if (!rect) return;
            const style = getComputedStyle(element);
            const x = rect.left - reportBounds.left;
            const y = rect.top - reportBounds.top;
            const background = style.backgroundColor;
            if (background !== 'transparent' && background !== 'rgba(0, 0, 0, 0)') {
                context.fillStyle = background;
                drawRoundedRect(x, y, rect.width, rect.height, parseFloat(style.borderTopLeftRadius) || 0);
                context.fill();
            }
            const borderWidth = Math.max(
                parseFloat(style.borderTopWidth) || 0,
                parseFloat(style.borderRightWidth) || 0,
                parseFloat(style.borderBottomWidth) || 0,
                parseFloat(style.borderLeftWidth) || 0
            );
            if (borderWidth && style.borderTopStyle !== 'none') {
                context.strokeStyle = style.borderTopColor;
                context.lineWidth = borderWidth;
                drawRoundedRect(x + borderWidth / 2, y + borderWidth / 2,
                    rect.width - borderWidth, rect.height - borderWidth,
                    parseFloat(style.borderTopLeftRadius) || 0);
                context.stroke();
            }
        });

        const images = Array.from(report.querySelectorAll('img'));
        for (const image of images) {
            if (typeof image.decode === 'function' && !image.complete) await image.decode();
            if (!image.naturalWidth) throw new Error('A report photo could not be rendered.');
            const rect = visibleRect(image);
            if (!rect) continue;
            const style = getComputedStyle(image);
            const x = rect.left - reportBounds.left;
            const y = rect.top - reportBounds.top;
            if (style.objectFit === 'contain') {
                const imageScale = Math.min(rect.width / image.naturalWidth, rect.height / image.naturalHeight);
                const imageWidth = image.naturalWidth * imageScale;
                const imageHeight = image.naturalHeight * imageScale;
                context.drawImage(image, x + (rect.width - imageWidth) / 2,
                    y + (rect.height - imageHeight) / 2, imageWidth, imageHeight);
            } else {
                context.drawImage(image, x, y, rect.width, rect.height);
            }
        }

        const wrapText = (text, maxWidth) => {
            const lines = [];
            for (const paragraph of text.split(/\r?\n/)) {
                let line = '';
                for (const word of paragraph.split(/\s+/).filter(Boolean)) {
                    const candidate = line ? `${line} ${word}` : word;
                    if (context.measureText(candidate).width <= maxWidth || !line) {
                        line = candidate;
                    } else {
                        lines.push(line);
                        line = word;
                    }
                }
                lines.push(line);
            }
            return lines;
        };
        const textWalker = document.createTreeWalker(report, NodeFilter.SHOW_TEXT);
        let textNode;
        while ((textNode = textWalker.nextNode())) {
            const text = textNode.nodeValue.trim();
            const parent = textNode.parentElement;
            if (!text || !parent) continue;
            const textRect = document.createRange();
            textRect.selectNodeContents(textNode);
            const bounds = textRect.getBoundingClientRect();
            if (!bounds.width || !bounds.height) continue;
            const style = getComputedStyle(parent);
            if (style.visibility === 'hidden') continue;
            const textStyle = `${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
            context.font = textStyle;
            context.fillStyle = style.color;
            context.textBaseline = 'top';
            const parentBounds = parent.getBoundingClientRect();
            const maxWidth = Math.max(1, parentBounds.width -
                (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0));
            const lineHeight = parseFloat(style.lineHeight) || (parseFloat(style.fontSize) || 14) * 1.35;
            const transformed = style.textTransform === 'uppercase' ? text.toUpperCase()
                : style.textTransform === 'lowercase' ? text.toLowerCase() : text;
            wrapText(transformed, maxWidth).forEach((line, index) => {
                context.fillText(line, bounds.left - reportBounds.left,
                    bounds.top - reportBounds.top + index * lineHeight, maxWidth);
            });
        }

        return await new Promise((resolve, reject) => {
            canvas.toBlob(blob => {
                if (blob) resolve(blob);
                else reject(new Error('The browser could not create the PNG file.'));
            }, 'image/png');
        });
    }

    async function openReportPreview(focusTarget = null) {
        const previewButton = byId('print-report');
        const walkthroughId = current?.id;
        previewButton.disabled = true;
        try {
            if (uploadBusy) throw new Error('Wait for file uploads to finish before previewing the report.');
            if (current?.version > 0 && !await loadAttachments()) {
                throw new Error('Could not load all linked photos. Resolve the photo errors and try again.');
            }
            if (current?.id !== walkthroughId || byId('editor-view').hidden) return;
            renderReportPreview();
            byId('preview-status').hidden = true;
            byId('report-preview').showModal();
            if (hasUnsavedChanges()) setStatus('Preview includes unsaved changes. Save the walkthrough to keep them.');
            if (focusTarget) byId(focusTarget).focus();
        } catch (error) {
            setStatus(`Could not prepare report preview: ${error.message}`, true);
        } finally {
            previewButton.disabled = false;
        }
    }

    async function imageForUpload(file) {
        if (file.size <= maxFileBytes) return file;
        if (!file.type.startsWith('image/')) throw new Error('Choose a file up to 3 MB.');
        if (typeof createImageBitmap !== 'function') throw new Error('This photo is larger than 3 MB and cannot be compressed in this browser.');
        const bitmap = await createImageBitmap(file);
        const scale = Math.min(1, 1800 / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        bitmap.close();
        for (const quality of [0.82, 0.68, 0.54]) {
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
            if (blob && blob.size <= maxFileBytes) {
                const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
                return new File([blob], name, { type: 'image/jpeg' });
            }
        }
        throw new Error('The photo could not be reduced below the 3 MB file limit.');
    }

    async function uploadAttachments(files, itemId, input) {
        if (!current || current.version === 0) {
            setStatus('Save the walkthrough before attaching files.', true);
            input.value = '';
            return;
        }
        uploadBusy = true;
        byId('attachment-input').disabled = true;
        byId('save-walkthrough').disabled = true;
        byId('delete-walkthrough').disabled = true;
        byId('area-list').querySelectorAll('.area-photo-input').forEach(control => { control.disabled = true; });
        let uploaded = 0;
        try {
            if (hasUnsavedChanges() && !await saveRecord()) return;
            byId('save-walkthrough').disabled = true;
            for (const original of files) {
                const file = await imageForUpload(original);
                const base64 = await file.arrayBuffer().then(buffer => {
                    const bytes = new Uint8Array(buffer);
                    let binary = '';
                    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
                        binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
                    }
                    return btoa(binary);
                });
                await api('files-upload', {
                    filename: file.name,
                    folder: 'Walkthroughs',
                    walkthroughId: current.id,
                    walkthroughItemId: itemId,
                    data: base64
                });
                uploaded++;
            }
            if (!await loadAttachments()) {
                throw new Error('Files were added, but some linked photos could not be loaded.');
            }
            setStatus(`${files.length} file${files.length === 1 ? '' : 's'} added.`);
        } catch (error) {
            setStatus(`Upload stopped after ${uploaded} file${uploaded === 1 ? '' : 's'}: ${error.message}`, true);
            if (uploaded) {
                try {
                    await loadAttachments();
                } catch (refreshError) {
                    setStatus(`Could not refresh attachments: ${refreshError.message}`, true);
                }
            }
        } finally {
            uploadBusy = false;
            input.value = '';
            byId('attachment-input').disabled = current?.version === 0;
            byId('save-walkthrough').disabled = !current?.canEdit;
            byId('delete-walkthrough').disabled = false;
            byId('area-list').querySelectorAll('.area-photo-input').forEach(control => {
                control.disabled = current?.version === 0;
            });
        }
    }

    byId('new-walkthrough').addEventListener('click', newRecord);
    byId('back-to-list').addEventListener('click', () => {
        if (uploadBusy) {
            setStatus('Wait for file uploads to finish before leaving the walkthrough.', true);
            return;
        }
        if (hasUnsavedChanges() && !confirm('Discard unsaved walkthrough changes?')) return;
        setEditorVisible(false);
        renderList();
    });
    window.addEventListener('beforeunload', event => {
        if (!byId('editor-view').hidden && (uploadBusy || hasUnsavedChanges())) {
            event.preventDefault();
            event.returnValue = '';
        }
    });
    byId('save-walkthrough').addEventListener('click', saveRecord);
    byId('add-area').addEventListener('click', () => addArea());
    byId('add-issue').addEventListener('click', () => addIssue());
    byId('walkthrough-date').value = today();
    byId('site').addEventListener('input', () => {
        if (current) byId('report-title').textContent = byId('site').value.trim() || 'New site walkthrough';
    });
    const refreshAreaState = () => {
        refreshAttachmentTargets();
        updateAreaReportVisibility();
    };
    byId('area-list').addEventListener('input', refreshAreaState);
    byId('area-list').addEventListener('change', refreshAreaState);
    byId('issue-list').addEventListener('input', refreshAttachmentTargets);
    byId('attachment-input').addEventListener('change', event => {
        if (event.target.files?.length) {
            uploadAttachments(Array.from(event.target.files), byId('attachment-link').value || null, event.target);
        }
    });
    byId('print-report').addEventListener('click', () => openReportPreview());
    byId('close-report-preview').addEventListener('click', () => byId('report-preview').close());
    byId('report-preview').addEventListener('close', () => byId('report-preview-content').replaceChildren());
    byId('save-report-pdf').addEventListener('click', () => window.print());
    byId('download-report-png').addEventListener('click', async event => {
        const button = event.currentTarget;
        button.disabled = true;
        try {
            setStatus('Preparing report PNG…');
            const siteName = byId('site').value.trim().replace(/[^a-z0-9._-]+/gi, '-').replace(/^-|-$/g, '') || 'walkthrough';
            downloadBlob(await reportPreviewPng(), `${siteName}-walkthrough.png`);
            setStatus('Report PNG downloaded.');
        } catch (error) {
            setStatus(`Could not export report PNG: ${error.message}`, true);
        } finally {
            button.disabled = false;
        }
    });
    byId('delete-walkthrough').addEventListener('click', async () => {
        if (!current?.canEdit || !confirm(`Delete the walkthrough for ${current.data.site}? Attached files remain in Files.`)) return;
        byId('delete-walkthrough').disabled = true;
        try {
            await api('walkthrough-delete', { id: current.id, version: current.version });
            records = records.filter(record => record.id !== current.id);
            current = null;
            setEditorVisible(false);
            renderList();
        } catch (error) {
            setStatus(`Could not delete walkthrough: ${error.message}`, true);
        } finally {
            byId('delete-walkthrough').disabled = false;
        }
    });

    api('walkthrough-state', {}).then(result => {
        if (!Array.isArray(result.walkthroughs)) throw new Error('The server returned an invalid walkthrough list.');
        records = result.walkthroughs;
        renderList();
    }).catch(error => {
        byId('save-status').textContent = 'Could not load';
        byId('empty-state').hidden = false;
        byId('empty-state').textContent = `Could not load walkthroughs: ${error.message}`;
    });
})();
