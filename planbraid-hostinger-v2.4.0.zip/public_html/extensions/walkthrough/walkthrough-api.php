<?php
/*
 * PlanBraid Walkthrough
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);

function walkthroughUuid(mixed $value): bool
{
    return is_string($value) && preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/i', $value) === 1;
}

function walkthroughText(mixed $value, int $max, bool $required = false): bool
{
    return is_string($value) && strlen($value) <= $max &&
        (!$required || trim($value) !== '') &&
        preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value) !== 1;
}

function walkthroughDate(mixed $value): bool
{
    if ($value === '') return true;
    if (!is_string($value) || preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $value) !== 1) return false;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

function walkthroughValidData(mixed $data): bool
{
    if (!is_array($data) ||
        !walkthroughText($data['customer'] ?? null, 160, true) ||
        !walkthroughText($data['site'] ?? null, 200, true) ||
        !walkthroughText($data['address'] ?? null, 500) ||
        !walkthroughText($data['contactName'] ?? null, 160) ||
        !walkthroughText($data['contactPhone'] ?? null, 80) ||
        !walkthroughText($data['lead'] ?? null, 120, true) ||
        !walkthroughDate($data['date'] ?? null) ||
        !is_array($data['areas'] ?? null) || !array_is_list($data['areas']) ||
        count($data['areas']) > 100 ||
        !is_array($data['systems'] ?? null) || !array_is_list($data['systems']) ||
        count($data['systems']) > 30 ||
        !is_array($data['issues'] ?? null) || !array_is_list($data['issues']) ||
        count($data['issues']) > 300) {
        return false;
    }

    $ids = [];
    foreach ($data['areas'] as $area) {
        if (!is_array($area) || !walkthroughUuid($area['id'] ?? null) ||
            isset($ids[$area['id']]) || !walkthroughText($area['name'] ?? null, 120, true) ||
            !walkthroughText($area['notes'] ?? null, 3000) ||
            !is_bool($area['applicable'] ?? null)) return false;
        $ids[$area['id']] = true;
    }

    if (array_key_exists('photoCaptions', $data)) {
        if (!is_array($data['photoCaptions']) || count($data['photoCaptions']) > 1000) return false;
        foreach ($data['photoCaptions'] as $fileId => $caption) {
            if (!preg_match('/\A[1-9][0-9]*\z/', (string) $fileId) ||
                !walkthroughText($caption, 200)) return false;
        }
    }

    $systemKeys = [];
    foreach ($data['systems'] as $system) {
        if (!is_array($system) || !walkthroughText($system['name'] ?? null, 100, true) ||
            !in_array($system['status'] ?? null, ['unreviewed', 'existing', 'planned', 'needs-work', 'na'], true) ||
            !walkthroughText($system['notes'] ?? null, 2000)) return false;
        $key = mb_strtolower(trim($system['name']), 'UTF-8');
        if (isset($systemKeys[$key])) return false;
        $systemKeys[$key] = true;
    }

    $issueIds = [];
    foreach ($data['issues'] as $issue) {
        if (!is_array($issue) || !walkthroughUuid($issue['id'] ?? null) ||
            isset($issueIds[$issue['id']]) ||
            !walkthroughText($issue['title'] ?? null, 250, true) ||
            !walkthroughText($issue['area'] ?? null, 120) ||
            !in_array($issue['priority'] ?? null, ['low', 'normal', 'high', 'urgent'], true) ||
            !in_array($issue['status'] ?? null, ['open', 'in-progress', 'resolved'], true) ||
            !walkthroughText($issue['action'] ?? null, 2000) ||
            !walkthroughDate($issue['dueDate'] ?? null)) return false;
        $issueIds[$issue['id']] = true;
    }
    return true;
}

if (($account['must_change_password'] ?? 1) || !(int) ($account['walkthrough_enabled'] ?? 0)) {
    respond(403, ['code' => 'extension_disabled', 'error' => 'Walkthrough is disabled for this account.']);
}

if ($action === 'walkthrough-state') {
    $rows = $db->query('SELECT w.id, w.version, w.data, w.created_by, w.updated_at
        FROM sl_walkthroughs w ORDER BY w.updated_at DESC, w.id DESC')->fetchAll(PDO::FETCH_ASSOC);
    $walkthroughs = array_map(static fn(array $row): array => [
        'id' => $row['id'],
        'version' => (int) $row['version'],
        'data' => json_decode($row['data'], true, 64, JSON_THROW_ON_ERROR),
        'canEdit' => (int) ($account['is_admin'] ?? 0) === 1 ||
            ($row['created_by'] !== null && (int) $row['created_by'] === (int) $account['id']),
        'updatedAt' => $row['updated_at'],
    ], $rows);
    respond(200, ['walkthroughs' => $walkthroughs]);
}

if ($action === 'walkthrough-save') {
    $id = $body['id'] ?? null;
    $version = $body['version'] ?? null;
    $data = $body['data'] ?? null;
    if (!walkthroughUuid($id) || !is_int($version) || $version < 0 || !walkthroughValidData($data)) {
        respond(400, ['error' => 'Enter valid site details, areas, systems, and walkthrough issues.']);
    }
    $json = json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (strlen($json) > 1048576) respond(413, ['error' => 'Walkthrough exceeds the 1 MB data limit.']);

    $db->beginTransaction();
    $account = currentAccount($db, true);
    if (!$account) { $db->rollBack(); respondSessionFailure($db); }
    if ((int) $account['must_change_password'] || !(int) $account['walkthrough_enabled']) {
        $db->rollBack();
        respond(403, ['code' => 'extension_disabled', 'error' => 'Walkthrough is disabled for this account.']);
    }
    if ($version === 0) {
        $statement = $db->prepare('INSERT INTO sl_walkthroughs (id, version, data, created_by, updated_by) VALUES (?, 1, ?, ?, ?)');
        try {
            $statement->execute([$id, $json, $account['id'], $account['id']]);
        } catch (PDOException $error) {
            if ($error->getCode() === '23000') {
                $db->rollBack();
                respond(409, ['error' => 'This walkthrough already exists. Refresh and try again.']);
            }
            throw $error;
        }
        $nextVersion = 1;
    } else {
        $statement = $db->prepare('SELECT version, created_by FROM sl_walkthroughs WHERE id = ? FOR UPDATE');
        $statement->execute([$id]);
        $existing = $statement->fetch(PDO::FETCH_ASSOC);
        if (!$existing) {
            $db->rollBack();
            respond(409, ['error' => 'This walkthrough was removed. Refresh before saving again.']);
        }
        if (!(int) $account['is_admin'] && (int) ($existing['created_by'] ?? 0) !== (int) $account['id']) {
            $db->rollBack();
            respond(403, ['code' => 'read_only', 'error' => 'Only the walkthrough creator or a PlanBraid administrator can edit it.']);
        }
        if ((int) $existing['version'] !== $version) {
            $db->rollBack();
            respond(409, ['error' => 'Another user changed this walkthrough. Refresh before saving again.']);
        }
        $statement = $db->prepare('UPDATE sl_walkthroughs SET data = ?, version = version + 1, updated_by = ? WHERE id = ? AND version = ?');
        $statement->execute([$json, $account['id'], $id, $version]);
        if ($statement->rowCount() !== 1) {
            $db->rollBack();
            respond(409, ['error' => 'Another user changed this walkthrough. Refresh before saving again.']);
        }
        $nextVersion = $version + 1;
    }
    $db->commit();
    respond(200, ['version' => $nextVersion]);
}

if ($action === 'walkthrough-delete') {
    $id = $body['id'] ?? null;
    $version = $body['version'] ?? null;
    if (!walkthroughUuid($id) || !is_int($version) || $version < 1) {
        respond(400, ['error' => 'Invalid walkthrough.']);
    }
    $db->beginTransaction();
    $account = currentAccount($db, true);
    if (!$account) { $db->rollBack(); respondSessionFailure($db); }
    if ((int) $account['must_change_password'] || !(int) $account['walkthrough_enabled']) {
        $db->rollBack();
        respond(403, ['code' => 'extension_disabled', 'error' => 'Walkthrough is disabled for this account.']);
    }
    $statement = $db->prepare('SELECT version, created_by FROM sl_walkthroughs WHERE id = ? FOR UPDATE');
    $statement->execute([$id]);
    $existing = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$existing) {
        $db->rollBack();
        respond(404, ['error' => 'Walkthrough not found.']);
    }
    if (!(int) $account['is_admin'] && (int) ($existing['created_by'] ?? 0) !== (int) $account['id']) {
        $db->rollBack();
        respond(403, ['code' => 'read_only', 'error' => 'Only the walkthrough creator or a PlanBraid administrator can delete it.']);
    }
    if ((int) $existing['version'] !== $version) {
        $db->rollBack();
        respond(409, ['error' => 'This walkthrough changed. Refresh and try again.']);
    }
    $statement = $db->prepare('DELETE FROM sl_walkthroughs WHERE id = ? AND version = ?');
    $statement->execute([$id, $version]);
    if ($statement->rowCount() !== 1) {
        $db->rollBack();
        respond(409, ['error' => 'This walkthrough changed or was removed. Refresh and try again.']);
    }
    $db->commit();
    respond(200, ['message' => 'Walkthrough deleted.']);
}

respond(404, ['error' => 'Unknown Walkthrough action.']);
