<?php
/*
 * PlanBraid - outlining, project tracking, and material orders.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 * Licensed under GNU AGPL version 3 or later; see LICENSE in the release root.
 * Distributed WITHOUT ANY WARRANTY, including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */
declare(strict_types=1);

function trackerValidText(mixed $value, int $max, bool $required = false): bool {
    return is_string($value) && mb_check_encoding($value, 'UTF-8')
        && mb_strlen($value) <= $max && (!$required || trim($value) !== '')
        && !preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $value);
}

function trackerValidDate(mixed $value): bool {
    if ($value === '') return true;
    if (!is_string($value) || !preg_match('/\A(\d{4})-(\d{2})-(\d{2})\z/', $value, $parts)) return false;
    return checkdate((int) $parts[2], (int) $parts[3], (int) $parts[1]);
}

function trackerValidId(mixed $value): bool {
    return is_string($value) && preg_match('/\A[a-zA-Z0-9_-]{1,80}\z/', $value) === 1;
}

function trackerApplyCreationMetadata(array $data, array $previous, string $username, string $now): array {
    foreach (['projects', 'tasks'] as $type) {
        $existing = [];
        foreach ($previous[$type] as $item) $existing[$item['id']] = $item;
        foreach ($data[$type] as &$item) {
            $old = $existing[$item['id']] ?? null;
            if ($old === null) {
                $item['createdAt'] = $now;
                if ($type === 'tasks') {
                    $item['owner'] = $username;
                    if (!array_key_exists('shared', $item)) $item['shared'] = false;
                }
            } else {
                if (array_key_exists('createdAt', $old)) $item['createdAt'] = $old['createdAt'];
                else unset($item['createdAt']);
                if ($type === 'tasks') {
                    $item['owner'] = $old['owner'];
                    if (!array_key_exists('shared', $item) && array_key_exists('shared', $old)) $item['shared'] = $old['shared'];
                }
            }
        }
        unset($item);
    }
    return $data;
}

function trackerVisibleState(array $data, string $username): array {
    $data['tasks'] = array_values(array_filter($data['tasks'], static fn(array $task): bool =>
        $task['owner'] === $username || ($task['shared'] ?? true) === true));
    $visible = array_fill_keys(array_column($data['tasks'], 'id'), true);
    foreach ($data['tasks'] as &$task) {
        if (isset($task['parentId']) && !isset($visible[$task['parentId']])) unset($task['parentId']);
    }
    unset($task);
    return $data;
}

function trackerMergeVisibleState(array $submitted, array $previous, string $username): ?array {
    if (!isset($submitted['tasks']) || !is_array($submitted['tasks']) || !array_is_list($submitted['tasks'])
        || count($submitted['tasks']) > 5000) return null;
    $old = [];
    foreach ($previous['tasks'] as $task) $old[$task['id']] = $task;
    $visible = [];
    foreach (trackerVisibleState($previous, $username)['tasks'] as $task) $visible[$task['id']] = $task;
    $seen = [];
    foreach ($submitted['tasks'] as &$task) {
        if (!is_array($task) || !trackerValidId($task['id'] ?? null) || isset($seen[$task['id']])) return null;
        $id = $task['id'];
        $seen[$id] = true;
        if (isset($old[$id]) && $old[$id]['owner'] !== $username) {
            if (!isset($visible[$id]) || $task != $visible[$id]) return null;
            $task = $old[$id];
        }
    }
    unset($task);
    foreach ($old as $id => $task) {
        if ($task['owner'] !== $username && !isset($seen[$id])) {
            if (isset($visible[$id])) return null;
            $submitted['tasks'][] = $task;
        }
    }
    return $submitted;
}

function trackerValidState(mixed $data): bool {
    if (!is_array($data)) return false;
    foreach (['projects', 'milestones', 'tasks'] as $key) {
        if (!isset($data[$key]) || !is_array($data[$key]) || !array_is_list($data[$key]) || count($data[$key]) > 5000) return false;
    }
    $projects = [];
    foreach ($data['projects'] as $project) {
        if (!is_array($project) || !trackerValidId($project['id'] ?? null) || isset($projects[$project['id']])
            || !trackerValidText($project['name'] ?? null, 200, true)
            || !trackerValidText($project['owner'] ?? null, 100, true)
            || !trackerValidDate($project['targetDate'] ?? null)) return false;
        $projects[$project['id']] = true;
    }
    $milestones = [];
    foreach ($data['milestones'] as $milestone) {
        if (!is_array($milestone) || !trackerValidId($milestone['id'] ?? null) || isset($milestones[$milestone['id']])
            || !trackerValidId($milestone['projectId'] ?? null) || !isset($projects[$milestone['projectId']])
            || !trackerValidText($milestone['name'] ?? null, 200, true)
            || !trackerValidDate($milestone['targetDate'] ?? null)) return false;
        $milestones[$milestone['id']] = true;
    }
    $tasks = [];
    foreach ($data['tasks'] as $task) {
        if (!is_array($task) || !trackerValidId($task['id'] ?? null) || isset($tasks[$task['id']])
            || !trackerValidText($task['title'] ?? null, 200, true)
            || !in_array($task['status'] ?? null, ['Backlog', 'Ready', 'In Progress', 'Blocked', 'Done'], true)
            || !in_array($task['priority'] ?? null, ['High', 'Normal', 'Low'], true)
            || !trackerValidText($task['owner'] ?? null, 100, true)
            || !trackerValidDate($task['dueDate'] ?? null)
            || !trackerValidId($task['milestoneId'] ?? null) || !isset($milestones[$task['milestoneId']])
            || !trackerValidText($task['blockedBy'] ?? null, 2000, ($task['status'] ?? null) === 'Blocked')
            || !trackerValidText($task['notes'] ?? null, 10000)) return false;
        if (isset($task['parentId']) && !trackerValidId($task['parentId'])) return false;
        if (array_key_exists('shared', $task) && !is_bool($task['shared'])) return false;
        if (isset($task['starred']) && !is_bool($task['starred'])) return false;
        if (isset($task['fieldNotes'])) {
            if (!is_array($task['fieldNotes']) || !array_is_list($task['fieldNotes']) || count($task['fieldNotes']) > 500) return false;
            $noteIds = [];
            foreach ($task['fieldNotes'] as $note) {
                if (!is_array($note) || !trackerValidId($note['id'] ?? null) || isset($noteIds[$note['id']])
                    || !trackerValidText($note['text'] ?? null, 2000, true)
                    || !trackerValidText($note['at'] ?? null, 40, true)) return false;
                $noteIds[$note['id']] = true;
            }
        }
        $tasks[$task['id']] = $task;
    }
    foreach ($tasks as $task) {
        $seen = [$task['id'] => true];
        $child = $task;
        while (isset($child['parentId'])) {
            $parentId = $child['parentId'];
            if (isset($seen[$parentId]) || !isset($tasks[$parentId]) || count($seen) > 50) return false;
            $parent = $tasks[$parentId];
            if ($child['milestoneId'] !== $parent['milestoneId'] || $child['owner'] !== $parent['owner']
                || ($parent['status'] === 'Done' && $child['status'] !== 'Done')) return false;
            $seen[$parentId] = true;
            $child = $parent;
        }
    }
    return true;
}
