<?php
/*
 * PlanBraid Files
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);

const PLANBRAID_FILE_MAX_BYTES = 3145728;

function filesUuid(mixed $value): bool
{
    return is_string($value) && preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/i', $value) === 1;
}

function filesCanUseLibrary(array $account): bool
{
    return !(int) $account['must_change_password'] && (int) $account['files_enabled'] === 1;
}

function filesCanUseWalkthroughAttachments(array $account): bool
{
    return !(int) $account['must_change_password'] && (int) $account['walkthrough_enabled'] === 1;
}

function filesFilename(mixed $filename): bool
{
    return is_string($filename) && trim($filename) !== '' && strlen($filename) <= 240 &&
        preg_match('/[\x00-\x1F\x7F\/\\\\]/', $filename) !== 1;
}

function filesFolder(mixed $folder): bool
{
    return is_string($folder) && strlen($folder) <= 120 &&
        preg_match('/[\x00-\x1F\x7F\/\\\\]/', $folder) !== 1;
}

function filesAllowedMime(string $mime, string $extension): bool
{
    $allowed = [
        'image/jpeg' => ['jpg', 'jpeg'],
        'image/png' => ['png'],
        'image/webp' => ['webp'],
        'application/pdf' => ['pdf'],
        'text/plain' => ['txt', 'csv'],
        'text/csv' => ['csv'],
    ];
    return in_array($extension, $allowed[$mime] ?? [], true);
}

function filesMetadataSql(): string
{
    return 'SELECT f.id, f.filename, f.mime_type, f.size_bytes, f.folder, f.walkthrough_id,
        f.walkthrough_item_id, f.uploaded_at, f.uploaded_by AS uploader_id, u.username AS uploaded_by
        FROM sl_files f LEFT JOIN sl_users u ON u.id = f.uploaded_by';
}

function filesRequireEnabled(array $account): void
{
    if ((int) $account['must_change_password'] || !(int) $account['files_enabled']) {
        respond(403, ['code' => 'extension_disabled', 'error' => 'Files is disabled for this account.']);
    }
}

$fileLibraryEnabled = filesCanUseLibrary($account);
$walkthroughEnabled = filesCanUseWalkthroughAttachments($account);

if ($action === 'files-list') {
    $walkthroughId = $body['walkthroughId'] ?? null;
    if ($walkthroughId !== null && !filesUuid($walkthroughId)) respond(400, ['error' => 'Invalid walkthrough link.']);
    if (!$fileLibraryEnabled && (!$walkthroughEnabled || !filesUuid($walkthroughId))) {
        filesRequireEnabled($account);
    }
    if ($walkthroughId !== null) {
        $statement = $db->prepare(filesMetadataSql() . ' WHERE f.walkthrough_id = ? ORDER BY f.uploaded_at DESC, f.id DESC');
        $statement->execute([$walkthroughId]);
    } else {
        $statement = $db->query(filesMetadataSql() . ' ORDER BY f.uploaded_at DESC, f.id DESC');
    }
    $files = array_map(static fn(array $file): array => [
        'id' => (int) $file['id'],
        'filename' => $file['filename'],
        'mimeType' => $file['mime_type'],
        'sizeBytes' => (int) $file['size_bytes'],
        'folder' => $file['folder'],
        'walkthroughId' => $file['walkthrough_id'],
        'walkthroughItemId' => $file['walkthrough_item_id'],
        'uploadedAt' => $file['uploaded_at'],
        'uploadedBy' => $file['uploaded_by'] ?? '',
        'canDelete' => (int) ($account['is_admin'] ?? 0) === 1 ||
            ($file['uploader_id'] !== null && (int) $file['uploader_id'] === (int) $account['id']),
    ], $statement->fetchAll(PDO::FETCH_ASSOC));
    respond(200, ['files' => $files]);
}

if ($action === 'files-upload') {
    $filename = $body['filename'] ?? null;
    $folder = $body['folder'] ?? '';
    $walkthroughId = $body['walkthroughId'] ?? null;
    $walkthroughItemId = $body['walkthroughItemId'] ?? null;
    $encoded = $body['data'] ?? null;
    if (!filesFilename($filename) || !filesFolder($folder) || !is_string($encoded) ||
        strlen($encoded) > 4194304 + 8 || $encoded === '') {
        respond(400, ['error' => 'Invalid file details or file data.']);
    }
    if ($walkthroughId !== null && !filesUuid($walkthroughId)) respond(400, ['error' => 'Invalid walkthrough link.']);
    if ($walkthroughItemId !== null && (!filesUuid($walkthroughItemId) || $walkthroughId === null)) {
        respond(400, ['error' => 'Invalid walkthrough item link.']);
    }
    if (!$fileLibraryEnabled && (!$walkthroughEnabled || $walkthroughId === null)) {
        filesRequireEnabled($account);
    }
    if ($walkthroughId !== null && !$walkthroughEnabled) {
        respond(403, ['code' => 'extension_disabled', 'error' => 'Walkthrough access is required to link files to a walkthrough.']);
    }
    $bytes = base64_decode($encoded, true);
    if ($bytes === false || strlen($bytes) < 1 || strlen($bytes) > PLANBRAID_FILE_MAX_BYTES) {
        respond(413, ['error' => 'Files must be no larger than 3 MB.']);
    }
    if (!class_exists(finfo::class)) {
        respond(500, ['error' => 'File type validation is unavailable on this server. Contact your administrator.']);
    }
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->buffer($bytes);
    if (!is_string($mime) || !filesAllowedMime($mime, $extension)) {
        respond(415, ['error' => 'Supported files are JPEG, PNG, WebP, PDF, CSV, and plain text.']);
    }
    if ($walkthroughId !== null) {
        $statement = $db->prepare('SELECT 1 FROM sl_walkthroughs WHERE id = ?');
        $statement->execute([$walkthroughId]);
        if (!$statement->fetchColumn()) respond(404, ['error' => 'Walkthrough not found.']);
    }
    if (!$fileLibraryEnabled) $folder = 'Walkthroughs';

    $db->beginTransaction();
    $account = currentAccount($db, true);
    if (!$account) { $db->rollBack(); respondSessionFailure($db); }
    if ((int) $account['must_change_password'] ||
        (!(int) $account['files_enabled'] && (!(int) $account['walkthrough_enabled'] || $walkthroughId === null))) {
        $db->rollBack();
        respond(403, ['code' => 'extension_disabled', 'error' => 'Files or linked Walkthrough access is disabled.']);
    }
    if ($walkthroughId !== null) {
        if (!(int) $account['walkthrough_enabled']) {
            $db->rollBack();
            respond(403, ['code' => 'extension_disabled', 'error' => 'Walkthrough access is required to link files to a walkthrough.']);
        }
        $statement = $db->prepare('SELECT data FROM sl_walkthroughs WHERE id = ? FOR UPDATE');
        $statement->execute([$walkthroughId]);
        $walkthroughData = $statement->fetchColumn();
        if (!is_string($walkthroughData)) {
            $db->rollBack();
            respond(404, ['error' => 'Walkthrough not found.']);
        }
        if ($walkthroughItemId !== null) {
            $data = json_decode($walkthroughData, true, 64, JSON_THROW_ON_ERROR);
            $itemIds = array_merge(
                array_column($data['areas'] ?? [], 'id'),
                array_column($data['issues'] ?? [], 'id')
            );
            if (!in_array($walkthroughItemId, $itemIds, true)) {
                $db->rollBack();
                respond(400, ['error' => 'The linked walkthrough item no longer exists.']);
            }
        }
    }
    $statement = $db->prepare('INSERT INTO sl_files
        (filename, mime_type, size_bytes, folder, data, walkthrough_id, walkthrough_item_id, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $statement->bindValue(1, $filename, PDO::PARAM_STR);
    $statement->bindValue(2, $mime, PDO::PARAM_STR);
    $statement->bindValue(3, strlen($bytes), PDO::PARAM_INT);
    $statement->bindValue(4, $folder, PDO::PARAM_STR);
    $statement->bindValue(5, $bytes, PDO::PARAM_LOB);
    $statement->bindValue(6, $walkthroughId, $walkthroughId === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
    $statement->bindValue(7, $walkthroughItemId, $walkthroughItemId === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
    $statement->bindValue(8, (int) $account['id'], PDO::PARAM_INT);
    $statement->execute();
    $id = (int) $db->lastInsertId();
    $db->commit();
    respond(200, ['id' => $id, 'message' => 'File uploaded.']);
}

if ($action === 'files-download') {
    $id = $body['id'] ?? null;
    if (!is_int($id) || $id < 1) respond(400, ['error' => 'Invalid file.']);
    $db->beginTransaction();
    $account = currentAccount($db, true);
    if (!$account) { $db->rollBack(); respondSessionFailure($db); }
    $statement = $db->prepare('SELECT id, filename, mime_type, size_bytes, data, walkthrough_id FROM sl_files WHERE id = ? FOR UPDATE');
    $statement->execute([$id]);
    $file = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$file) {
        $db->rollBack();
        respond(404, ['error' => 'File not found.']);
    }
    $libraryEnabled = !(int) $account['must_change_password'] && (int) $account['files_enabled'] === 1;
    $attachmentsEnabled = !(int) $account['must_change_password'] && (int) $account['walkthrough_enabled'] === 1;
    if (!$libraryEnabled && (!$attachmentsEnabled || $file['walkthrough_id'] === null)) {
        $db->rollBack();
        filesRequireEnabled($account);
    }
    $db->commit();
    respond(200, [
        'id' => (int) $file['id'],
        'filename' => $file['filename'],
        'mimeType' => $file['mime_type'],
        'sizeBytes' => (int) $file['size_bytes'],
        'data' => base64_encode($file['data']),
    ]);
}

if ($action === 'files-delete') {
    $id = $body['id'] ?? null;
    if (!is_int($id) || $id < 1) respond(400, ['error' => 'Invalid file.']);
    $db->beginTransaction();
    $account = currentAccount($db, true);
    if (!$account) { $db->rollBack(); respondSessionFailure($db); }
    $statement = $db->prepare('SELECT walkthrough_id, uploaded_by FROM sl_files WHERE id = ? FOR UPDATE');
    $statement->execute([$id]);
    $file = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$file) {
        $db->rollBack();
        respond(404, ['error' => 'File not found.']);
    }
    $libraryEnabled = !(int) $account['must_change_password'] && (int) $account['files_enabled'] === 1;
    $attachmentsEnabled = !(int) $account['must_change_password'] && (int) $account['walkthrough_enabled'] === 1;
    if (!$libraryEnabled && (!$attachmentsEnabled || $file['walkthrough_id'] === null)) {
        $db->rollBack();
        filesRequireEnabled($account);
    }
    if (!(int) $account['is_admin'] && (int) ($file['uploaded_by'] ?? 0) !== (int) $account['id']) {
        $db->rollBack();
        respond(403, ['code' => 'read_only', 'error' => 'Only the uploader or a PlanBraid administrator can delete this file.']);
    }
    $statement = $db->prepare('DELETE FROM sl_files WHERE id = ?');
    $statement->execute([$id]);
    $db->commit();
    respond(200, ['message' => 'File deleted.']);
}

respond(404, ['error' => 'Unknown Files action.']);
