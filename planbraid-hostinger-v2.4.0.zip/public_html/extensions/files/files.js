/*
 * PlanBraid Files
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
(() => {
    if (window.parent === window || typeof window.parent.api !== 'function') {
        document.getElementById('library-status').textContent = 'Open Files from PlanBraid.';
        return;
    }

    const api = window.parent.api;
    const maxFileBytes = 3 * 1024 * 1024;
    let files = [];
    let walkthroughs = [];
    let walkthroughAccess = false;
    let activePreviewUrl = null;
    let previewTrigger = null;
    let busy = false;
    const byId = id => document.getElementById(id);

    function setStatus(element, message, error = false) {
        element.textContent = message;
        element.dataset.state = error ? 'error' : '';
    }

    function formatBytes(bytes) {
        return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    }

    function folderLabel(folder) {
        return folder || 'Unfiled';
    }

    function walkthroughLabel(id) {
        return walkthroughs.find(record => record.id === id)?.data.site || 'Walkthrough';
    }

    function refreshFolderFilter() {
        const filter = byId('folder-filter');
        const selected = filter.value;
        const folders = [...new Set(files.map(file => file.folder || ''))]
            .sort((left, right) => folderLabel(left).localeCompare(folderLabel(right)));
        filter.replaceChildren(new Option('All folders', 'all'));
        folders.forEach(folder => filter.add(new Option(folderLabel(folder), `folder:${folder}`)));
        if (folders.some(folder => `folder:${folder}` === selected)) filter.value = selected;
        else filter.value = 'all';
    }

    function renderFiles() {
        refreshFolderFilter();
        const query = byId('search-files').value.trim().toLocaleLowerCase();
        const folder = byId('folder-filter').value;
        const filtered = files.filter(file => {
            if (folder !== 'all' && `folder:${file.folder || ''}` !== folder) return false;
            const searchText = [file.filename, file.folder, file.uploadedBy, file.mimeType, file.walkthroughId ? walkthroughLabel(file.walkthroughId) : '']
                .join(' ').toLocaleLowerCase();
            return !query || searchText.includes(query);
        });
        const grid = byId('file-grid');
        grid.replaceChildren();
        filtered.forEach(file => grid.appendChild(makeFileCard(file)));
        byId('file-count').textContent = `${files.length} file${files.length === 1 ? '' : 's'}`;
        byId('empty-state').hidden = filtered.length > 0;
        if (files.length && !filtered.length) byId('empty-state').textContent = 'No files match this search or folder.';
        else byId('empty-state').textContent = 'No files yet. Upload a file to start the library.';
    }

    function makeFileCard(file) {
        const card = document.createElement('article');
        card.className = 'file-card';
        const title = document.createElement('h3');
        title.textContent = file.filename;
        const details = document.createElement('p');
        const date = file.uploadedAt ? new Date(`${file.uploadedAt.replace(' ', 'T')}Z`).toLocaleDateString() : '';
        details.textContent = `${file.mimeType} · ${formatBytes(file.sizeBytes)}${file.uploadedBy ? ` · ${file.uploadedBy}` : ''}${date ? ` · ${date}` : ''}`;
        const tags = document.createElement('div');
        tags.className = 'file-tags';
        const folder = document.createElement('span');
        folder.className = 'tag';
        folder.textContent = folderLabel(file.folder);
        tags.appendChild(folder);
        if (file.walkthroughId) {
            const linked = document.createElement('span');
            linked.className = 'tag';
            linked.textContent = walkthroughLabel(file.walkthroughId);
            tags.appendChild(linked);
        }
        const actions = document.createElement('div');
        actions.className = 'file-actions';
        const preview = document.createElement('button');
        preview.type = 'button';
        preview.className = 'button';
        preview.textContent = 'Preview';
        preview.disabled = !['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'text/plain', 'text/csv'].includes(file.mimeType);
        preview.addEventListener('click', () => showPreview(file, preview));
        const download = document.createElement('button');
        download.type = 'button';
        download.className = 'button';
        download.textContent = 'Download';
        download.addEventListener('click', () => downloadFile(file, download));
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'button button-danger';
        remove.textContent = 'Delete';
        remove.hidden = !file.canDelete;
        remove.addEventListener('click', () => deleteFile(file, remove));
        actions.append(preview, download, remove);
        card.append(title, details, tags, actions);
        return card;
    }

    async function getFileContent(file, button) {
        button.disabled = true;
        setStatus(byId('library-status'), `Loading ${file.filename}…`);
        try {
            const result = await api('files-download', { id: file.id });
            const binary = atob(result.data);
            const bytes = new Uint8Array(binary.length);
            for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
            return new Blob([bytes], { type: result.mimeType });
        } finally {
            button.disabled = false;
            setStatus(byId('library-status'), '');
        }
    }

    async function showPreview(file, button) {
        const dialog = byId('preview-dialog');
        const content = byId('preview-content');
        previewTrigger = button;
        content.replaceChildren();
        byId('preview-title').textContent = file.filename;
        try {
            const blob = await getFileContent(file, button);
            if (activePreviewUrl) URL.revokeObjectURL(activePreviewUrl);
            activePreviewUrl = URL.createObjectURL(blob);
            let previewElement;
            if (file.mimeType.startsWith('image/')) {
                previewElement = document.createElement('img');
                previewElement.alt = file.filename;
                previewElement.src = activePreviewUrl;
            } else if (file.mimeType === 'application/pdf') {
                previewElement = document.createElement('iframe');
                previewElement.title = file.filename;
                previewElement.src = activePreviewUrl;
            } else {
                previewElement = document.createElement('pre');
                previewElement.textContent = await blob.text();
            }
            content.appendChild(previewElement);
            dialog.showModal();
            byId('close-preview').focus();
        } catch (error) {
            setStatus(byId('library-status'), `Could not preview file: ${error.message}`, true);
        }
    }

    function base64FromBlob(blob) {
        return blob.arrayBuffer().then(buffer => {
            const bytes = new Uint8Array(buffer);
            let binary = '';
            for (let offset = 0; offset < bytes.length; offset += 0x8000) {
                binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
            }
            return btoa(binary);
        });
    }

    async function downloadFile(file, button) {
        try {
            const blob = await getFileContent(file, button);
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = file.filename;
            link.click();
            setTimeout(() => URL.revokeObjectURL(url), 60000);
        } catch (error) {
            setStatus(byId('library-status'), `Could not download file: ${error.message}`, true);
        }
    }

    async function deleteFile(file, button) {
        if (!confirm(`Delete ${file.filename} from the shared library?`)) return;
        button.disabled = true;
        try {
            await api('files-delete', { id: file.id });
            files = files.filter(item => item.id !== file.id);
            renderFiles();
            setStatus(byId('library-status'), 'File deleted.');
        } catch (error) {
            setStatus(byId('library-status'), `Could not delete file: ${error.message}`, true);
            button.disabled = false;
        }
    }

    async function imageForUpload(file) {
        if (file.size <= maxFileBytes) return file;
        if (!file.type.startsWith('image/')) throw new Error('Choose a file up to 3 MB.');
        if (typeof createImageBitmap !== 'function') throw new Error(`“${file.name}” is larger than 3 MB and cannot be compressed in this browser.`);
        const bitmap = await createImageBitmap(file);
        const scale = Math.min(1, 1800 / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        bitmap.close();
        for (const quality of [0.82, 0.68, 0.54]) {
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
            if (blob && blob.size <= maxFileBytes) {
                return new File([blob], file.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg' });
            }
        }
        throw new Error(`“${file.name}” could not be reduced below the 3 MB limit.`);
    }

    async function uploadFiles(selectedFiles) {
        if (busy) return;
        busy = true;
        byId('file-input').disabled = true;
        setStatus(byId('upload-status'), 'Uploading…');
        let uploaded = 0;
        try {
            const folder = byId('folder-name').value.trim();
            const walkthroughId = byId('walkthrough-link').value || null;
            for (const original of selectedFiles) {
                const file = await imageForUpload(original);
                const data = await base64FromBlob(file);
                await api('files-upload', {
                    filename: file.name,
                    folder,
                    walkthroughId,
                    data
                });
                uploaded++;
                setStatus(byId('upload-status'), `Uploaded ${uploaded} of ${selectedFiles.length}…`);
            }
            byId('file-input').value = '';
            files = (await api('files-list', {})).files;
            renderFiles();
            setStatus(byId('upload-status'), `${uploaded} file${uploaded === 1 ? '' : 's'} uploaded.`);
        } catch (error) {
            setStatus(byId('upload-status'), `Upload stopped after ${uploaded} file${uploaded === 1 ? '' : 's'}: ${error.message}`, true);
            if (uploaded) {
                try {
                    files = (await api('files-list', {})).files;
                    renderFiles();
                } catch (refreshError) {
                    setStatus(byId('library-status'), `Could not refresh the library: ${refreshError.message}`, true);
                }
            }
        } finally {
            busy = false;
            byId('file-input').value = '';
            byId('file-input').disabled = false;
        }
    }

    async function initialize() {
        try {
            const session = await api('session');
            if (!session.authenticated || !session.filesEnabled) throw new Error('Files is disabled for this account.');
            walkthroughAccess = session.walkthroughEnabled;
            byId('walkthrough-field').hidden = !walkthroughAccess;
            if (walkthroughAccess) {
                const result = await api('walkthrough-state', {});
                if (!Array.isArray(result.walkthroughs)) throw new Error('The server returned an invalid walkthrough list.');
                walkthroughs = result.walkthroughs;
                const select = byId('walkthrough-link');
                walkthroughs.forEach(record => select.add(new Option(record.data.site || 'Untitled site', record.id)));
            }
            const result = await api('files-list', {});
            if (!Array.isArray(result.files)) throw new Error('The server returned an invalid file list.');
            files = result.files;
            renderFiles();
            setStatus(byId('library-status'), '');
        } catch (error) {
            setStatus(byId('library-status'), `Could not open Files: ${error.message}`, true);
            byId('empty-state').hidden = false;
            byId('empty-state').textContent = 'The shared library is unavailable.';
            byId('file-count').textContent = 'Unavailable';
            byId('file-input').disabled = true;
        }
    }

    byId('file-input').addEventListener('change', event => {
        if (event.target.files?.length) uploadFiles(Array.from(event.target.files));
    });
    byId('search-files').addEventListener('input', renderFiles);
    byId('folder-filter').addEventListener('change', renderFiles);
    byId('close-preview').addEventListener('click', () => byId('preview-dialog').close());
    byId('preview-dialog').addEventListener('close', () => {
        byId('preview-content').replaceChildren();
        if (activePreviewUrl) URL.revokeObjectURL(activePreviewUrl);
        activePreviewUrl = null;
        previewTrigger?.focus();
        previewTrigger = null;
    });
    byId('preview-dialog').addEventListener('click', event => {
        if (event.target === byId('preview-dialog')) byId('preview-dialog').close();
    });
    initialize();
})();
