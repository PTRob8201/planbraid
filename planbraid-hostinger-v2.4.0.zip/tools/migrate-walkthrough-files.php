<?php
/*
 * PlanBraid Walkthrough and Files schema migration.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$config = require dirname(__DIR__) . '/planbraid-private/database.php';
$db = new PDO(
    'mysql:host=' . $config['host'] . ';dbname=' . $config['database'] . ';charset=utf8mb4',
    $config['username'],
    $config['password'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
);

foreach (['walkthrough_enabled', 'files_enabled'] as $column) {
    $statement = $db->prepare('SELECT DATA_TYPE, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?');
    $statement->execute([$config['database'], 'sl_account_access', $column]);
    $existing = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$existing) {
        $db->exec("ALTER TABLE sl_account_access ADD COLUMN `$column` TINYINT UNSIGNED NOT NULL DEFAULT 0");
        $statement->execute([$config['database'], 'sl_account_access', $column]);
        $existing = $statement->fetch(PDO::FETCH_ASSOC);
    }
    if (!$existing || $existing['DATA_TYPE'] !== 'tinyint' ||
        !str_contains($existing['COLUMN_TYPE'], 'unsigned') ||
        $existing['IS_NULLABLE'] !== 'NO' || (string) $existing['COLUMN_DEFAULT'] !== '0') {
        throw new RuntimeException("Unexpected account metadata definition for $column; migration stopped.");
    }
}

$db->exec("CREATE TABLE IF NOT EXISTS sl_walkthroughs (
    id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
    version BIGINT UNSIGNED NOT NULL,
    data LONGTEXT NOT NULL,
    created_by INT UNSIGNED NULL,
    updated_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY sl_walkthroughs_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS sl_files (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(240) NOT NULL,
    mime_type VARCHAR(80) NOT NULL,
    size_bytes INT UNSIGNED NOT NULL,
    folder VARCHAR(120) NOT NULL DEFAULT '',
    data MEDIUMBLOB NOT NULL,
    walkthrough_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
    walkthrough_item_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
    uploaded_by INT UNSIGNED NULL,
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY sl_files_walkthrough (walkthrough_id, walkthrough_item_id, uploaded_at),
    KEY sl_files_folder (folder),
    CONSTRAINT sl_files_walkthrough_fk FOREIGN KEY (walkthrough_id)
        REFERENCES sl_walkthroughs (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

foreach ([
    'sl_walkthroughs' => ['id', 'version', 'data', 'created_by', 'updated_by', 'created_at', 'updated_at'],
    'sl_files' => ['id', 'filename', 'mime_type', 'size_bytes', 'folder', 'data', 'walkthrough_id', 'walkthrough_item_id', 'uploaded_by', 'uploaded_at'],
] as $table => $expectedColumns) {
    $statement = $db->prepare('SELECT COLUMN_NAME FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION');
    $statement->execute([$config['database'], $table]);
    if ($statement->fetchAll(PDO::FETCH_COLUMN) !== $expectedColumns) {
        throw new RuntimeException("Unexpected $table table definition; migration stopped.");
    }
    $statement = $db->prepare('SELECT ENGINE FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND TABLE_TYPE = ?');
    $statement->execute([$config['database'], $table, 'BASE TABLE']);
    if (strcasecmp((string) $statement->fetchColumn(), 'InnoDB') !== 0) {
        throw new RuntimeException("Unexpected $table storage engine; migration stopped.");
    }
}

echo "Walkthrough and Files migrations verified.\n";
