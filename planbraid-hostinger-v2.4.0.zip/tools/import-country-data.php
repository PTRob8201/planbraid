<?php
/*
 * PlanBraid - outlining, project tracking, and material orders.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc !== 2) throw new InvalidArgumentException('Usage: php import-country-data.php COUNTRY_CSV_GZ');
// DB-IP November 2026 Lite: checksum is for the uncompressed CSV.
if (hash_file('sha1', 'compress.zlib://' . $argv[1]) !== 'e2061015c43ec91c94a12191a6a613279eb94c0c') {
    throw new RuntimeException('Country dataset does not match the verified November 2026 release.');
}
$config = require dirname(__DIR__) . '/planbraid-private/database.php';
$db = new PDO('mysql:host=' . $config['host'] . ';dbname=' . $config['database'] . ';charset=utf8mb4',
    $config['username'], $config['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]);
$input = gzopen($argv[1], 'rb');
if ($input === false) throw new RuntimeException('Cannot open country dataset.');
$db->beginTransaction();
try {
    $db->exec('DELETE FROM sl_country_ranges');
    $batch = [];
    $last = [];
    $count = 0;
    $insert = static function (array $batch) use ($db): void {
        $sql = 'INSERT INTO sl_country_ranges (family, ip_start, ip_end, country) VALUES ' .
            implode(',', array_fill(0, count($batch), '(?,?,?,?)'));
        $db->prepare($sql)->execute(array_merge(...$batch));
    };
    while (($line = gzgets($input)) !== false) {
        $fields = str_getcsv($line, ',', '"', '');
        if (count($fields) !== 3 || preg_match('/\A[A-Z]{2}\z/', $fields[2]) !== 1) throw new RuntimeException('Invalid country CSV row.');
        $start = inet_pton($fields[0]);
        $end = inet_pton($fields[1]);
        if ($start === false || $end === false || strlen($start) !== strlen($end) || strcmp($start, $end) > 0) {
            throw new RuntimeException('Invalid country range.');
        }
        $family = strlen($start) === 4 ? 4 : 6;
        if (isset($last[$family]) && strcmp($start, $last[$family]) <= 0) throw new RuntimeException('Country ranges overlap or are not ordered.');
        $last[$family] = $end;
        $batch[] = [$family, str_pad($start, 16, "\0", STR_PAD_LEFT), str_pad($end, 16, "\0", STR_PAD_LEFT), $fields[2]];
        $count++;
        if (count($batch) === 500) { $insert($batch); $batch = []; }
    }
    if (!gzeof($input)) throw new RuntimeException('Could not finish reading country data.');
    if ($batch) $insert($batch);
    if ($count !== 732796 || (int) $db->query('SELECT COUNT(*) FROM sl_country_ranges')->fetchColumn() !== $count) {
        throw new RuntimeException('Country dataset record count does not match.');
    }
    $db->commit();
    echo "Verified and imported $count country ranges (DB-IP November 2026).\n";
} catch (Throwable $error) {
    $db->rollBack();
    throw $error;
} finally {
    gzclose($input);
}
