<?php
/*
 * PlanBraid Continuum schema migration.
 * Copyright (C) 2026 Robert Wasniowski
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$config = require dirname(__DIR__) . '/planbraid-private/database.php';
$db = new PDO(
    'mysql:host=' . $config['host'] . ';dbname=' . $config['database'] . ';charset=utf8mb4',
    $config['username'],
    $config['password'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
);
$statement = $db->prepare('SELECT DATA_TYPE, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?');
$statement->execute([$config['database'], 'sl_account_access', 'continuum_enabled']);
$column = $statement->fetch(PDO::FETCH_ASSOC);
if (!$column) {
    $db->exec('ALTER TABLE sl_account_access ADD COLUMN continuum_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0');
    $statement->execute([$config['database'], 'sl_account_access', 'continuum_enabled']);
    $column = $statement->fetch(PDO::FETCH_ASSOC);
}
if (!$column || $column['DATA_TYPE'] !== 'tinyint' ||
    !str_contains($column['COLUMN_TYPE'], 'unsigned') || $column['IS_NULLABLE'] !== 'NO' ||
    (string) $column['COLUMN_DEFAULT'] !== '0') {
    throw new RuntimeException('Unexpected Continuum access column definition.');
}
$db->exec('CREATE TABLE IF NOT EXISTS sl_continuum_workspaces (
    user_id INT UNSIGNED NOT NULL PRIMARY KEY,
    revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
    data LONGTEXT NOT NULL,
    CONSTRAINT sl_continuum_user FOREIGN KEY (user_id) REFERENCES sl_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$statement = $db->prepare('SELECT COLUMN_NAME, DATA_TYPE, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION');
$statement->execute([$config['database'], 'sl_continuum_workspaces']);
$columns = $statement->fetchAll(PDO::FETCH_ASSOC);
if (array_column($columns, 'COLUMN_NAME') !== ['user_id', 'revision', 'data'] ||
    $columns[0]['DATA_TYPE'] !== 'int' || !str_contains($columns[0]['COLUMN_TYPE'], 'unsigned') ||
    $columns[0]['IS_NULLABLE'] !== 'NO' || $columns[0]['COLUMN_KEY'] !== 'PRI' ||
    $columns[1]['DATA_TYPE'] !== 'bigint' || !str_contains($columns[1]['COLUMN_TYPE'], 'unsigned') ||
    $columns[1]['IS_NULLABLE'] !== 'NO' || (string) $columns[1]['COLUMN_DEFAULT'] !== '0' ||
    $columns[2]['DATA_TYPE'] !== 'longtext' || $columns[2]['IS_NULLABLE'] !== 'NO') {
    throw new RuntimeException('Unexpected Continuum workspace table definition.');
}
$statement = $db->prepare('SELECT COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND CONSTRAINT_NAME = ? ORDER BY ORDINAL_POSITION');
$statement->execute([$config['database'], 'sl_continuum_workspaces', 'PRIMARY']);
if ($statement->fetchAll(PDO::FETCH_COLUMN) !== ['user_id']) {
    throw new RuntimeException('Unexpected Continuum workspace primary key.');
}
$statement = $db->prepare('SELECT k.COLUMN_NAME, k.REFERENCED_TABLE_NAME, k.REFERENCED_COLUMN_NAME, r.DELETE_RULE
    FROM information_schema.KEY_COLUMN_USAGE k
    JOIN information_schema.REFERENTIAL_CONSTRAINTS r
      ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME
      AND r.TABLE_NAME = k.TABLE_NAME
    WHERE k.TABLE_SCHEMA = ? AND k.TABLE_NAME = ? AND k.REFERENCED_TABLE_NAME IS NOT NULL');
$statement->execute([$config['database'], 'sl_continuum_workspaces']);
$foreignKeys = $statement->fetchAll(PDO::FETCH_ASSOC);
if (count($foreignKeys) !== 1 || $foreignKeys[0]['COLUMN_NAME'] !== 'user_id' ||
    $foreignKeys[0]['REFERENCED_TABLE_NAME'] !== 'sl_users' ||
    $foreignKeys[0]['REFERENCED_COLUMN_NAME'] !== 'id' || $foreignKeys[0]['DELETE_RULE'] !== 'CASCADE') {
    throw new RuntimeException('Unexpected Continuum workspace foreign key.');
}
$statement = $db->prepare('SELECT ENGINE FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND TABLE_TYPE = ?');
$statement->execute([$config['database'], 'sl_continuum_workspaces', 'BASE TABLE']);
if (strcasecmp((string) $statement->fetchColumn(), 'InnoDB') !== 0) {
    throw new RuntimeException('Unexpected Continuum workspace storage engine.');
}
echo "Continuum migration verified.\n";
