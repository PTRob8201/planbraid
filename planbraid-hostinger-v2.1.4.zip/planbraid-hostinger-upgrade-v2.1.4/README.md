# PlanBraid Hostinger upgrade to v2.1.4

Copyright (C) 2026 Robert Wasniowski. App source is licensed under
AGPL-3.0-or-later; see `public_html/LICENSE`. No warranty.

This package is for the existing **v2.0.0 root installation** on Hostinger,
not a fresh installation and not the home-server upgrade. It retains the
Hostinger root session-cookie path and its existing private database config.
The shared PlanBraid PM and Supply extensions are separate from the older
optional project-management module. Their app files are in
`public_html/extensions/pm/` and `public_html/extensions/supply/`.
They use the same PlanBraid login and per-account access controls.

The package has been tested with synthetic databases; it has **not** been
installed or tested on this Hostinger account. Do not upload the package as
an archive into the public web root. No passwords, existing accounts, orders,
workspaces, or backups are included.

## Before making changes

1. Ask all users to save, export any unsynced work, and sign out. Schedule
   downtime; do not allow edits while migrating or replacing files.
2. Create and verify a current backup of both the existing application files
   (including `.htaccess` and private `planbraid-private/database.php`) and
   the MySQL database. The Hostinger backup started on November 21 should be
   checked for completeness; additionally export the selected database from
   phpMyAdmin and securely download the existing files. Backups and exports
   contain sensitive data and must never be placed under a web root.
3. Confirm the currently served app is v2.0.0 and this is the intended site
   root. Confirm HTTPS, PHP 8.1 or later, PDO MySQL, PDO SQLite and mbstring.
   The PHP process must be able to read `planbraid-private/database.php` and
   read/write a SQLite file and its parent directory there. If `open_basedir`
   prevents access outside the web root, stop; do not put private data in
   the public directory.
4. Publish this package's **source files** to the public source repository and
   create tag `v2.1.4-hostinger` before deployment. Both in-app source links
   point to that tag. Include `public_html/`, this README, `migrate-v2.0.0.sql`,
   `private-supply/schema.sql`, and `tests/`. The empty SQLite template can
   be regenerated from `private-supply/schema.sql`; do not publish any
   populated database, credentials, backups, or user data.
5. In phpMyAdmin select the **existing PlanBraid database**, and inspect the
   schema before migration. `sl_account_access` must have `email`,
   `must_change_password` and `guide_seen`, but must not already have
   `pm_enabled`, `supply_enabled`, `supply_role` or
   `personal_project_pending`; `sl_shared_tracker` must not exist. Stop if
   any expectation differs; do not delete or overwrite tables.

## Install

1. Ensure `planbraid-private/supply.sqlite` does not already exist. Upload
   `private-supply/supply.sqlite` to that exact private location, alongside
   `database.php`, outside every web root. It is an empty new Supply database
   with one General category and `ea` unit. Do not replace an existing file.
   Set file permissions to `600` and directory permissions to `700` if the
   Hostinger PHP user can access them. The directory must be writable for
   SQLite journals. Never upload `private-supply` into `public_html`.
2. In phpMyAdmin, select the existing PlanBraid database and import
   `migrate-v2.0.0.sql` **once**. It adds four account columns and the empty
   shared tracker table; PM and Supply default off. MySQL DDL is not
   transactional. If anything fails, stop: do not retry blindly, delete
   tables, or proceed with file replacement. Review schema and restore or
   repair using the verified backup.
3. Upload the **contents** of this package's `public_html/` to the site's
   existing `public_html/`, merging directories and replacing only same-named
   app files. Preserve the existing `.htaccess`, private config, legacy root
   scripts, and unrelated files. Do not upload `tests/`, `private-supply/`,
   or the SQL migration into the web root. Keep the backup until recovery is
   no longer needed.
4. Publish the exact deployed source under `v2.1.4-hostinger`; verify the
   **More options → Help → Source code** link works. Do not expose private
   configuration or any real databases.

## Verify

- Check `https://planbraid.com/` still opens the landing page and
  `https://planbraid.com/index.html` opens the app. Sign in, save a small
  disposable test note, reload, and confirm it persists.
- As an administrator open **More options → Manage accounts**, enable PM and
  Supply for a test account, and select the intended Supply role. Both start
  disabled for existing accounts. Verify the shared PM workspace opens empty,
  Supply opens with an empty catalog, and the chosen account's access works.
- Check the source link and License dialog. Confirm the private config and
  SQLite database cannot be fetched over HTTPS. Stop and restrict access if
  either is reachable; do not disclose the file contents.
- Verify access restrictions with a separate test account: a technician can
  see only their own orders, and cannot edit the catalog. Review PHP error logs
  if Supply fails. Preserve the verified backups.

To roll back, stop access, back up the current state, and restore the old files
and database together from the verified snapshot. Restoring a database loses
changes made since that snapshot; the new Supply database is separate and
must be backed up before changing or replacing it.

## Build and tests

Compiled styles are included. Rebuild Core with Tailwind CSS v4.3.5 from
`public_html/assets/css/`: `tailwindcss -i tailwind-input.css -o tailwind.css`,
and `tailwindcss -i design-NAME.input.css -o design-NAME.css` for each theme.
Rebuild Supply with Tailwind CSS v3.4.17 from `public_html/`:
`tailwindcss -i extensions/supply/supply-input.css -o extensions/supply/supply.css --content extensions/supply/supply-app.html --minify`.
The generated styles retain Tailwind's MIT notice.

On a test machine with PHP, Python, MariaDB server and client tools, run
`python3 -m unittest -v tests.test_hostinger`. The test uses disposable
synthetic databases; never run it against production. The browser fixtures
in `tests/` can be served locally from the package root.
