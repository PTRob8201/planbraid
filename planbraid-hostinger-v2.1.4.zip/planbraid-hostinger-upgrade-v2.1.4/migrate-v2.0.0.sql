-- PlanBraid Hostinger upgrade from v2.0.0 only.
-- Copyright (C) 2026 Robert Wasniowski
-- SPDX-License-Identifier: AGPL-3.0-or-later
-- See public_html/LICENSE. Distributed WITHOUT ANY WARRANTY.
-- Run only once after verifying a backup. MySQL DDL is not transactional.
ALTER TABLE sl_account_access
  ADD COLUMN pm_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN supply_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN supply_role VARCHAR(12) NOT NULL DEFAULT 'technician',
  ADD COLUMN personal_project_pending TINYINT UNSIGNED NOT NULL DEFAULT 1;
CREATE TABLE sl_shared_tracker (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  version BIGINT UNSIGNED NOT NULL,
  data LONGTEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
