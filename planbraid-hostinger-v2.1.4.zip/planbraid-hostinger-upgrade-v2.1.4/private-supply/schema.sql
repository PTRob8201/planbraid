-- PlanBraid Supply initial database schema.
-- Copyright (C) 2026 Robert Wasniowski
-- SPDX-License-Identifier: AGPL-3.0-or-later
-- See public_html/LICENSE. Distributed WITHOUT ANY WARRANTY.
PRAGMA foreign_keys = ON;
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE shared (name TEXT PRIMARY KEY, version INTEGER NOT NULL, data TEXT NOT NULL);
CREATE TABLE orders (
  id TEXT PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  version INTEGER NOT NULL,
  data TEXT NOT NULL
);
INSERT INTO shared VALUES ('settings', 1, '{"categories":["General"],"units":["ea"],"defaultUnit":"ea"}');
INSERT INTO shared VALUES ('catalog', 1, '[]');
